Required external Libraries:
	bs4 (BeautifulSoup)
	json
	urllib

This program has 2 separate starting option:
'Build Index'
'Query'

if you would like to build a new index, please type 'BUILDINDEX'
as your first input

any other input will result in the 'Query' component of the program


BUILDINDEX will then prompt the user for a path in which the files you want to be 
indexed are located, then will take around 30 minutes depending on how many files are being indexed
to build index files on disk.

QUERY will take some time to build auxilliary structures from index and files on disk
	After some start-up time, program will prompt the user for a query
	once the query is entered, the top 10 most relevant queries are returned
	Query will also return the query evaluation time in seconds

User will be continously prompted for a new query until an empty query is given.
