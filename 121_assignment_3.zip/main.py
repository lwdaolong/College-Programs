import os
import json
import partA
import sys
from bs4 import BeautifulSoup
from timeit import default_timer as timer
import random
import math
import re
import statistics
from urllib.parse import urldefrag
from urllib.parse import urlparse


''' #psuedocode for inverted index algorithm

proc BUILDINDEX(D):
    DocIdList = list()
    I = dict()
    n =0
    for doc in D: #find method that recursively looks through directory for all files
        AppendPostingsForDoc(I,doc,n, DocIdList)
        n = n+1 #fenceposting, first doc will be docID 0


    sort and print to outputfile

#feel like it might be more efficient and modular if a separate CreatePostingForDoc() method creates
#instances of a posting class on a per document data, able to scale off of more things than just tokens later on

AppendPostingsForDoc(Index, currdoc, docID, DOCIDLIST):
    DOCIDLIST.append(currdoc.url)
    #parse whatever other extra info you need in the parse METHOD
    #T is a dictionary associated with the key as token, value as a tuple of all extra information
    T = parse(doc) # use assignment 1 dictionary for tokens (so that they count frequency and no collapsing is needed)
    for token,info in T.items():
        I[token].append(posting(docID,token,tok_freq))


#Posting is a class acting as a vessel for all information related to a posting

class Posting:
    def __init__(self, docID, token, tok_freq):
        self.docID = docID
        self.token = token
        self.tok_freq = tok_feq
        #and whatever other variables you think a Posting should keep track of


'''

def string_tokenize_include_period(s):
    tokenlist = []
    alphaNumericRegex = re.compile(r"[a-zA-Z0-9\.]+")
    for line in s.splitlines():
        alpha_numeric_sequence_match = alphaNumericRegex.findall(line)
        #print(alpha_numeric_sequence_match)
        for sequence in alpha_numeric_sequence_match:
            tokenlist.append(sequence.lower())
    return tokenlist

def ConvertFreqToLogTermFreq(tok_freq):
    if tok_freq <= 0:
        return 0
    return 1 + math.log10(tok_freq)


class Posting:
    def __init__(self, docID, token, tok_freq):
        self.docID = docID
        self.token = token
        self.tok_freq = tok_freq
        #and whatever other variables you think a Posting should keep track of

    def __str__(self): #string representation used in posting, so does not involve the token attribtutes, format (docID: info1,info2,...infoN)
        tempstr = '('
        tempstr += str(self.docID)
        tempstr += ': '
        tempstr += str(self.tok_freq)
        tempstr += ')'

        #^this can be done better with string formatting whoops
        return tempstr

'''
    Input
        'query_tokens': a list of tokens from a given query
        'INDEXOFINDEX': dictionary structure of index of index
        'DOCIDLIST': list representing dociD and accompanying url
    Return
        a list of urls that represent documents that contained every token in the query, at the moment no ranking of urls
'''
def SimpleBooleanANDDocMatch(query_tokens, INDEXOFINDEX,DOCIDLIST):
    d =set()
    #initial set of documents for first query token added to dictionary
    outputfile = open('finalIndex.txt', 'r') #, make this an input filepath for distributed indexes if you want that later?
    if query_tokens[0] not in INDEXOFINDEX:
        return []#empty list because token not indexed, cant be found in any doc
        #potentially print error message as well?
    placement = int(INDEXOFINDEX[query_tokens[0]])
    outputfile.seek((placement))

    # HANDLE ERRORS OF NOT EXISTING QUERY TOKEN

    initialtokendocs = ParseIndexLine(outputfile.readline())
    #print(initialtokendocs[1])
    for doctuple in initialtokendocs[1]:
        #doesn't fact frequency in at all yet
        d.add(doctuple)

    #some redundant work here, will optimize later
    for tok in query_tokens:
        if tok not in INDEXOFINDEX:
            return []  # empty list because token not indexed, cant be found in any doc
            # potentially print error message as well?
        placement = int(INDEXOFINDEX[tok])
        outputfile.seek((placement))

        tokendocs = ParseIndexLine(outputfile.readline())
        d = set( d ) & set( tokendocs[1].keys() )
    return [DOCIDLIST[int(docID)] for docID in d]


'''
    Input
        'filepath': a filepath that should point to a txt file created by BUILDINDEX that represents the list of document IDS associated with the real url
    Return
        a list of urls, where their index represents their docID
'''
def ParseDocIDList(filepath):
    d = []
    # Opening file
    file1 = open(filepath, 'r')
    for line in file1:
        d.append(line.strip())

    file1.close()
    return d

def ParseDocSizeList(filepath):
    d = []
    # Opening file
    file1 = open(filepath, 'r')
    for line in file1:
        d.append(int(line.strip()))

    file1.close()
    return d


'''
    Input
        'filepath': a filepath that should point to a txt file created by BUILDINDEX that represents the index of the inverted index
    Return
        a dictionary with key value pairs token:byte placement in invertedindex file
'''
def ParseIndexOfIndex(filepath):
    d = {}
    # Opening file
    file1 = open(filepath, 'r')
    for line in file1:
        templist = partA.string_tokenize(line)
        d[templist[0]] = templist[1]

    file1.close()
    return d
'''
    Input
        's': a string that should represent a singular line from the index file built by BUILDINDEX
    Return
        a tuple of (token,dictionary) for the given token on that line, maybe change data structure returned later to incorporate ranking
'''
def ParseIndexLineD(s):
    # note may need to change parse algorithm when more statistics are added to index
    #postinglinecomponents = partA.string_tokenize(s)
    postinglinecomponents = string_tokenize_include_period(s)
    t = postinglinecomponents[0] #assuming first item is the token itself
    d = {}
    for i in range(1,len(postinglinecomponents),2):
        if d.get(postinglinecomponents[i]) == None:
            d[postinglinecomponents[i]] = 0
        d[postinglinecomponents[i]] = (postinglinecomponents[i+1])
    return (t,d)


def ParseIndexLine(s):
    # note may need to change parse algorithm when more statistics are added to index
    #postinglinecomponents = partA.string_tokenize(s)
    postinglinecomponents = string_tokenize_include_period(s)
    t = postinglinecomponents[0] #assuming first item is the token itself
    d = {}
    for i in range(1,len(postinglinecomponents),2):
        if d.get(postinglinecomponents[i]) == None:
            d[postinglinecomponents[i]] = list()
        d[postinglinecomponents[i]].append(postinglinecomponents[i+1])
    return (t,d)



'''
Input
    'Index': a hashmap of string 'token' keys, with a list of posting instances as value
    'currdoc': the dictionary structure of an opened json file corresponding to a given document
    'docID': the document Identification Serial Number of the document currently being assessed, will be used as tag for document in postings
    'DOCIDLIST': an auxillary list, where the index represents the DocID number and the value is the actual string url of that document DOCIDLIST[docID] = 'example.com'
'''
def AppendPostingsForDoc(Index, currdoc, docID, DOCIDLIST, DOCSIZELIST):
    if urldefrag(currdoc['url'])[0] in DOCIDLIST or re.match(r"(^action=diff)|(post_type=tribe)|(filter)",(urlparse(currdoc['url'])).query):
        DOCIDLIST.append(currdoc['url']) #add even though won't be used in search to not mess with index of this file
        DOCSIZELIST.append(1000) #arbitrary
        return


    DOCIDLIST.append(currdoc['url'])
    #parse whatever other extra info you need in the parse METHOD
    #T is a dictionary associated with the key as token, value as a tuple of all extra information

    soup = BeautifulSoup(currdoc['content'], 'lxml')

    #TODO TEST OPTIMIZATION, REMOVE TEXT FROM LINKS
    for a in soup.findAll('a', href=True):
        a.extract()

    # tokenizes content of page
    text = soup.get_text()
    token_list = partA.string_tokenize(text)

    #append to auxilliary structure, size of webpage
    DOCSIZELIST.append(len(token_list))

    token_frequencies = partA.computeWordFrequencies(token_list)

    #this step pre-normalizes the tf weight of each document as its posting is being added
    #document length
    doc_tf_weight_length = 0
    for token, info in token_frequencies.items():
        #sum up the squared tf weights
        doc_tf_weight_length += (ConvertFreqToLogTermFreq(info)**2)
    #now doc_tf_weight_length now represents the length of the document tf weight vector
    doc_tf_weight_length = math.sqrt(doc_tf_weight_length)

    for token,info in token_frequencies.items():

        if Index.get(token) == None:
            Index[token] = list()
        #info transformed into log term freqency/ length of the entire document weights, normalized to optimize for cosine
        #similarity later on
        Index[token].append(Posting(docID,token,(ConvertFreqToLogTermFreq(info))/doc_tf_weight_length))

'''
Input
    'indexLine': a string taken from an index .txt file, should be in form of '{token} : ({docID}: {tok_freq}), ({docID}: {tok_freq}),....'
Return
    [Posting] a list of postings is returned, each posting object created from the tuple ({docID}: {tok_freq}), in the indexLine string
'''
# CHANGE WHEN TF IDF
def parseTokenPostings(indexLine):
    postinglist = []
    #postinglinecomponents = partA.string_tokenize(indexLine)
    postinglinecomponents = string_tokenize_include_period(indexLine)
    t = postinglinecomponents[0]  # assuming first item is the token itself
    for i in range(1, len(postinglinecomponents), 2):
        postinglist.append(Posting(postinglinecomponents[i],t,postinglinecomponents[i+1]))
    return postinglist


'''
Input
    'postinglist1': a list of Posting class objects related to one list of postings
    'postinglist2': a list of Posting class objects related to one list of postings
Return
    [Posting] a list of postings is returned, the ordering of the Posting objects in the list should be sorted (e.g.) pstinglist1 +postinglist2
'''
# CHANGE WHEN TF IDF
def mergePostingList(postinglist1,postinglist2):
    newpostinglist = []
    for posting in postinglist1:
        newpostinglist.append(posting)
    for posting2 in postinglist2:
        newpostinglist.append(posting2)
    return newpostinglist

'''
Input
    'batch_index': a dictionary of the current in-memory inverted index (tokens:postinglist), will be merged with inverted index associated with pathofexternalindex
    'pathofexternalindex': a path to an existing external .txt file that represents a previously constructed inverted index on disk, will be merged with batch_index
    'merge_index': used to denote the name of the resulting merged inverted index's .txt file
                    IF NEGATIVE, returns 'finalIndex.txt'
                    IF NONNEGATIVE, returns 'tempIndex{merge_index}.txt'
Return
    'path to newly merged inverted index on disk, .txt file'
'''
# change when TF IDF
def sortAndWriteToMasterIndexOutput(batch_index,pathofexternalindex,merge_index = -1):
    #merge the dictionary and existing .txt file into a NEW file thats created every time this function is called
    #return the path to that newly created file, which will be used the next time a batch merge is needed
    #use string formatting to format these indexed merged batches to see the progress of the index at every batch
    #after the final merge and sort, rename the path to something that is globally used, e.g. FINALINDEX
    #a merge index of negative int indicates the "final merge", which will return a path of FINALINDEX, any non-negative merge_index will return a named file based on that index

    #turn the batched index dictionary into a list and sort it
    unique_pages_list = [(key, value) for key, value in batch_index.items()]
    unique_pages_list.sort()
    #this makes it easier to merge the batch and existing index(which also is assumed to already be sorted) so that the final index is in sorted order

    #open a new file with a formatted string based on params (final or indexed)
    #open the file supplied by parameters
    #step through the list and opened file, writing to the new outputfile at each step
    #close files and returned newly created output file path

    #create new file path for merged partial indexes
    new_file_path = 'tempIndex.txt'
    if(merge_index > -1):
        new_file_path = 'tempIndex{}.txt'.format(merge_index)
    else:
        new_file_path = 'finalIndex.txt'

    #mew file that end of merge is being written into
    with open(new_file_path, 'w') as outputfile:
        externaldumpfile = open(pathofexternalindex, 'r') #existing file that is being used to merge with local memory
        line = externaldumpfile.readline()

        #pointer keeps track of index of local memory data structure reprenting partial index
        localindexpointer = 0

        #ensures that no index out of bound errror happens
        while(localindexpointer < len(unique_pages_list) and line):
            localtoken = unique_pages_list[localindexpointer][0]
            externaltoken = ParseIndexLine(line)[0]
            if localtoken < externaltoken:
                #write posting line to external file from local partial index structure
                outputfile.write('%s : ' % localtoken)
                for posting in unique_pages_list[localindexpointer][1]:
                    outputfile.write('%s, ' % posting)

                outputfile.write('\n')
                #increment pointer
                localindexpointer +=1
            elif externaltoken < localtoken:
                # write posting line to external file from external partial index file
                outputfile.write('%s : ' % externaltoken)
                tmppostinglist = parseTokenPostings(line)
                for posting in tmppostinglist:
                    outputfile.write('%s, ' % posting)

                outputfile.write('\n')
                # increment pointer
                line = externaldumpfile.readline()
            else: #then assumes the tokens are equal and a merge is required
                outputfile.write('%s : ' % localtoken)
                tmppostinglist = parseTokenPostings(line)
                #merge step
                mergedpostinglist = mergePostingList(tmppostinglist,unique_pages_list[localindexpointer][1])

                for posting in mergedpostinglist:
                    outputfile.write('%s, ' % posting)

                outputfile.write('\n')

                #increment both pointers
                localindexpointer += 1
                line = externaldumpfile.readline()

        #reaching this point implies that at least one structure (local partial index or external file) is empty
        #if any leftover data still exists, slap that at the end of the file

        #if data still leftover in external file, add to new file
        if line:
            #print('contine from external')
            while line:
                externaltoken = ParseIndexLine(line)[0]
                outputfile.write('%s : ' % externaltoken)
                tmppostinglist = parseTokenPostings(line)
                for posting in tmppostinglist:
                    outputfile.write('%s, ' % posting)

                outputfile.write('\n')
                # increment pointer
                line = externaldumpfile.readline()

        # if data still leftover in local partial index structure, add to new file
        if localindexpointer < len(unique_pages_list):
            #print('contine from local')
            for index in range(localindexpointer,len(unique_pages_list)):
                outputfile.write('%s : ' % unique_pages_list[index][0])
                for posting in unique_pages_list[index][1]:
                    outputfile.write('%s, ' % posting)

                outputfile.write('\n')

        externaldumpfile.close()

    # RETURN NEW PATH TO UPDATED/MERGED INDEX
    return new_file_path

'''
    Input
        'filepath': a filepath that should point to a txt file created by BUILDINDEX that represents the reference of token to its IDF (inverted document freq)
    Return
        a dictionary with key value pairs token:IDF value based on full index
'''
def ParseIDF_REF(filepath):
    d = {}
    # Opening file
    file1 = open(filepath, 'r')
    for line in file1:
        templist = string_tokenize_include_period(line)
        d[templist[0]] = float(templist[1])

    file1.close()
    return d


'''
    Input
        'filepath': a filepath that should point to a txt file created by BUILDINDEX that represents the fully constructed index finalIndex.txt
        'tot_num_docs': an int value representing the total number of documents in the index
    Return
        NONE
        However, creates a IDF_REF.txt auxilliary file that will be used to look-up tokens and their associated IDF values based on the fully constructed index
'''
def CreateIDF_REF(filepath, tot_num_docs):
    finalindex = open(filepath,'r')
    with open('IDF_REF.txt', 'w') as outputfile:
        # idea, once index is fully built, read the index with readline and use tell after each call to get the starting index of each line
        for line in finalindex:
            templist = string_tokenize_include_period(line)
            #templist[0] is token of given line
            if (len(templist) <= 0):
                pass

            #might be kind of dodgy, but making assumption that a given posting list that has been tokenized
            #will be odd (1 tok for the actual token, and +2 for each pair of (docID, frequency)), so the lower floor of dividing by 2 will give the count of
            #documents with the given token
            count = int(len(templist)/2)
            idf = math.log10(tot_num_docs/count)

            #print(templist[0],'===', idf)
            outputfile.write('%s : %f\n' % (templist[0], idf))
    finalindex.close()


''' 
Input 'D': is the starting directory/path of the json files you want to index
will recursively search through all subdirectories and files within 'D' and index each document to an inverted index
That inverted index will then be sorted by token and printed to an outputfile
'''
def BUILDINDEX(D):
    DocSizeList = list()
    DocIdList = list()
    I = dict()
    n = 0 #represents docID and number of docs
    #curr_temp_index keeps track of the constantly changing filepath of the most recently updated index
    curr_temp_index = 'tempIndex.txt'
    for root, d_names, f_names in os.walk(D):
        for filename in f_names:
            #if the length of the hashmap I goes past a certain 'large' threshold, say  41943136/5 '6990523', then merge into main output file and
            #start a new batch to reduce memory usage
            #sys.getsizeof() returns physical bytes of object, lets assume 'large' in our case is a million bytes

            if(sys.getsizeof(I) > 6990523): #should result in around 6-7 batches in dev corpus
                curr_temp_index = sortAndWriteToMasterIndexOutput(I,curr_temp_index,n) #using n here to not add a redundant counting int, represents the docID that the current batch ended at
                #clears local memory for new batch
                I.clear()
                #DEBUG
                #print('batch dumped')


            temppath = os.path.join(root,filename) #this might be a little wonky on other machines?
            f = open(temppath)
            data = json.load(f)
            AppendPostingsForDoc(I,data,n, DocIdList,DocSizeList)
            f.close()
            n = n+1 #fenceposting, first doc will be docID 0


    #sort and print to outputfile one final time
    final_index_path = sortAndWriteToMasterIndexOutput(I, curr_temp_index) #final merge, no index given
    I.clear()
    #print(sys.getsizeof(I))


    #print DocIdList to auxillary file
    with open('DOCIDREFERENCE.txt', 'w') as outputfile:
        for count,element in enumerate(DocIdList):
            outputfile.write('%s\n' % (element))
            #outputfile.write('%d : %s\n' % (count,element)) #PRETTY PRINT

    # print DocSizeList to auxillary file
    with open('DOCSIZEREFERENCE.txt', 'w') as outputfile:
        for count, element in enumerate(DocSizeList):
            outputfile.write('%s\n' % (element))
            # outputfile.write('%d : %s\n' % (count,element)) #PRETTY PRINT

    #print Index_of_Index to auxillaary file
    Index_of_Index = {}
    file1 = open(final_index_path, 'r') #opens index file
    tmploc = file1.tell()
    line = file1.readline()
    templist = partA.string_tokenize(line)
    Index_of_Index[templist[0]] = tmploc
    while line:
        tmploc = file1.tell()
        line = file1.readline()
        templist = partA.string_tokenize(line)
        if (len(templist) > 0):
            Index_of_Index[templist[0]] = tmploc
    file1.close()
    with open('INDEXOFINDEX.txt', 'w') as outputfile:
        #idea, once index is fully built, read the index with readline and use tell after each call to get the starting index of each line
        for k,v in Index_of_Index.items():
            outputfile.write('%s : %d\n' % (k,v))

    #create auxilliary structure to reference token to IDF
    CreateIDF_REF(final_index_path,n)

    #print(DocIdList)
    return I


def tokenize_query():
    query_tokens = []
    if(len(sys.argv) == 1):
        print('INVALID USAGE of command', str(sys.argv[0]))
        print(str(sys.argv[0]), '[QUERY]')

    for count,arg in enumerate(sys.argv):
        if count!=0:
            temp_tokens = partA.string_tokenize(arg)
            for t in temp_tokens:
                query_tokens.append(t)
    return query_tokens


'''
    Input
        'query_tokens': a list of tokens from a given query
        'idf_ref': a dictionary created from ParseIDF_REF(), represents key,value of token:IDF value
    Return
        a dictionary with key value pairs token:LTC weighted value of token in query and index (log tok freq in query* idf of index)
'''
def constructLTCQueryVector(query_tokens, idf_ref):
    token_frequencies = partA.computeWordFrequencies(query_tokens)
    # this step pre-normalizes the tf weight of each document as its posting is being added

    #dictionary to be returned
    normalized_TLC_query_dict = {}

    # query length
    query_tf_idf_weight_length = 0
    for token, info in token_frequencies.items():
        # sum up the squared tf-idf weights
        curr_idf = 0
        if token in idf_ref:
            curr_idf = idf_ref[token]
        query_tf_idf_weight_length += ((ConvertFreqToLogTermFreq(info)*curr_idf) ** 2)

    # now doc_tf_weight_length now represents the length of the document tf weight vector
    query_tf_idf_weight_length = math.sqrt(query_tf_idf_weight_length)

    #used to prevent queries with no terms that are indexed to not result in crash
    if(query_tf_idf_weight_length) ==0:
        query_tf_idf_weight_length = 1

    for token, info in token_frequencies.items():
        curr_idf = 0
        if token in idf_ref:
            curr_idf = idf_ref[token]
        normalized_TLC_query_dict[token] =  (ConvertFreqToLogTermFreq(info)*curr_idf) / query_tf_idf_weight_length

    return normalized_TLC_query_dict

'''
    Input
        'query_vector': a dictionary representing key,value pairs of query_token:normalizedtf*idf, using the ltc standard for query vector
        'INDEXOFINDEX': dictionary structure of index of index
        'DOCIDLIST': list representing dociD and accompanying url
    Return
        a list of urls that represent documents that contained at least one token in the query, ranked by relevance score 
        relevance score calculated by the cos dot product of each document to the given query vector
'''
def CosQueryMatch(query_vector, INDEXOFINDEX,DOCIDLIST,DOCSIZELIST,mediandocsize):
    d = {}
    #initial set of documents for first query token added to dictionary
    outputfile = open('finalIndex.txt', 'r')

    #optimize search by first sorting by rarest weights in query
    queryvectorsorteddescendingrarestterms = [(wt,token) for token,wt in query_vector.items()]
    queryvectorsorteddescendingrarestterms.sort(reverse=True)
    print(queryvectorsorteddescendingrarestterms)


    #some redundant work here, will optimize later
    #for tok,ltc_wt in query_vector.items():
    for ltc_wt, tok in queryvectorsorteddescendingrarestterms:
        if tok not in INDEXOFINDEX:
            continue
        placement = int(INDEXOFINDEX[tok])
        outputfile.seek((placement))

        tokendocs = ParseIndexLineD(outputfile.readline())
        for docid,lnc_wt in tokendocs[1].items():
            #optimize so number of considered documents never over 1000
            if d.get(docid) == None:
                if len(d) < 30000:
                    d[docid] = 0
            if docid in d:
                d[docid] += float(lnc_wt)*ltc_wt

    #cosine similarity is good, but heavily emphasizes documents of smaller length
    #this is because even if a document has the suggested token, smaller documents will have more heavily weighted normalized
    #log tf values

    #need to add an extra heuristic that emphasizes medium sized documents
    #this is a trade off and my personal choice
    #My justification: smaller pages are not textually important and should be less relevant
    #even if they have query terms
    #to do this, going to add heuristic that includes the inverse delta in doc length compared to median doc length of indexed pages
    #TODO turn this feature off and use for report when talking about optimizations
    #not sure if I want to normalize these inverse document size values by taking the exp() of them yet
    #for now, no normalization, lets see how it does



    docsizeweight = .001

    for did, relevance in d.items():
        divisor = abs(mediandocsize - DOCSIZES[int(did)])
        if divisor == 0:
            #arbitrary nonzero to prevent divide by zero error
            divisor = .0000000000000000000000001
        d[did] *= docsizeweight * (1/(divisor))











    #compute and sort list of tuples (relevance_score,docID)
    scores = [(relevance,did) for did,relevance in d.items()]
    scores.sort(reverse=True)

    #print(scores)

    return [DOCIDLIST[int(docID[1])] for docID in scores]

'''
Input
    's': user input given as query
    'INDEXOFINDEX': dictionary structure of index of index
    'DOCIDLIST': list representing dociD and accompanying url
RETURN
    as of now, just prints results of query, but can/maybe modify to return a list that could be outputted somewhere else
    
'''
def GetQueryResults(s, INDEXOFINDEX,DOCIDLIST,IDF_REF,DOCSIZES,mediandocsize):

    '''

    start = timer()
    query_tokens = partA.string_tokenize(s)
    QUERYRESULTS = SimpleBooleanANDDocMatch(query_tokens, Index_of_Index, DOCIDS)
    # this is a temporary line because no logic has been introduced to rank the query results, this will choose 5 random results
    tempqueryresults = QUERYRESULTS
    if(len(QUERYRESULTS) > 5):
        tempqueryresults = random.sample(QUERYRESULTS,5)
    end = timer()
    print(tempqueryresults)
    #print(QUERYRESULTS)
    print(end - start)
    '''

    start = timer()
    query_tokens = partA.string_tokenize(s)
    query_vector = constructLTCQueryVector(query_tokens,IDF_REF)
    #QUERYRESULTS = SimpleBooleanANDDocMatch(query_tokens, Index_of_Index, DOCIDS)
    QUERYRESULTS = CosQueryMatch(query_vector, INDEXOFINDEX, DOCIDLIST,DOCSIZES,mediandocsize)
    #returns top 5 results at the moment
    tempqueryresults = QUERYRESULTS
    #TODO change to n number of results
    if(len(QUERYRESULTS) > 10):
        tempqueryresults = QUERYRESULTS[0:9]
    end = timer()
    print(tempqueryresults)
    #print(QUERYRESULTS)
    print(end - start)


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    inputActive = True
    user_option = input('Please Choose An Option: "BUILDINDEX" will build a new INDEX, default will jump to normal search')
    if user_option == 'BUILDINDEX':
        path = input('Please enter path of files you want to be included in the index')
        # path = "./ANALYST"
        #path = "./DEV"
        try:
            inverted_index = BUILDINDEX(path)
        except:
            print('PATHERROR: path provided was not accessible')
            exit()

        inputActive = False
    try:

        #generate Auxilliary structures
        DOCSIZES = ParseDocSizeList('DOCSIZEREFERENCE.txt')
        #mediandocsize = statistics.median(DOCSIZES)

        DOCIDS = ParseDocIDList('DOCIDREFERENCE.txt')
        Index_of_Index = ParseIndexOfIndex('INDEXOFINDEX.txt')
        IDF_REF = ParseIDF_REF('IDF_REF.txt')

    except:
        #checks if preliminary files exist or not
        #if reaching this point, at least one auxilliary index file not  found
        print('ERROR: Index files corrupted, please rebuild index')
        print('Ending Program')
        exit()

    inputActive = True
    # ask user for query input
    # if no input, close program, else return documents
    print('Please Enter Your Query: ')
    if inputActive:
        user_query = input()
    while (user_query != ''):  # close out program if no query is given
        GetQueryResults(user_query, Index_of_Index, DOCIDS,IDF_REF,DOCSIZES,150)
        user_query = input('Please Enter Your Query: ')

    print('Ending Program')








'''

        for element in unique_pages_list:
            # also write token locations in this index file to the INDEX OF INDEX file for faster look-up

            outputfile.write('%s : ' % element[0])
            for posting in element[1]:
                outputfile.write('%s, ' % posting)

            outputfile.write('\n')
'''
