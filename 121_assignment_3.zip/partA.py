#partA.py

#allows for command line input
import sys
import os
import re

#list of stop words found from https://www.ranks.nl/stopwords
default_english_stop_list = ['a','about','above','after','again','against','all','am','an','and','any','are',"aren't",'as','at','be','because','been','before','being','below','between','both','but','by',"can't",'cannot','could',"couldn't",'did',"didn't",'do','does',"doesn't",'doing',"don't",'down','during','each','few','for','from','further','had',"hadn't",'has',"hasn't",'have',"haven't",'having','he',"he'd","he'll","he's",'her','here',"here's",'hers','herself','him','himself','his','how',"how's",'i',"i'd","i'll","i'm","i've",'if','in','into','is',"isn't",'it',"it's",'its','itself',"let's",'me','more','most',"mustn't",'my','myself','no','nor','not','of','off','on','once','only','or','other','ought','our','ours',"ourselves","out","over","own","same","shan't","she","she'd","she'll","she's","should","shouldn't","so","some","such","than","that","that's","the","their","theirs","them","themselves","then","there","there's","these","they","they'd","they'll","they're","they've","this","those","through","to","too","under","until","up","very","was","wasn't","we","we'd","we'll","we're","we've","were","weren't","what","what's","when","when's","where","where's","which","while","who","who's","whom","why","why's","with","won't","would","wouldn't","you","you'd","you'll","you're","you've","your","yours","yourself","yourselves"]


#takes input of system filepath, should be a .txt or some type of text readable file
#returns a list of strings that consist of sequences of alphanumeric characters from text file belonging to 'filepath'
#throws exception if file belonging to 'filepath' cannot be opened
#tokenize()'s complexity scales linearly with the number of characters within a file, although the file is read line by line,
#each character is analyzed for a regex pattern match, so this method is O(n) where n is the number of characters in a file

def string_tokenize(s):
    tokenlist = []
    alphaNumericRegex = re.compile(r"[a-zA-Z0-9]+")
    for line in s.splitlines():
        alpha_numeric_sequence_match = alphaNumericRegex.findall(line)
        #print(alpha_numeric_sequence_match)
        for sequence in alpha_numeric_sequence_match:
            tokenlist.append(sequence.lower())
    return tokenlist

def tokenize(filepath):
    # validates filepath
    abspath = os.path.abspath(filepath)
    #attempts to open file
    #used to close file later if successfully opened
    f = None
    #attempt to open file, gracefully exit program if not
    try:
        f = open(abspath,'r',encoding='utf-8')
    except:
        print('File:', abspath, 'cannot be opened, Exiting Program')
        exit(0)

    #creates list
    tokenlist = []

    # define alphanumeric regex object
    alphaNumericRegex = re.compile(r"[a-zA-Z0-9]+")

    #read file line by line
    for line in f:
        #logic for regexing a single line of input into tokens
        #choosing to not include singular 'n' of \n newline characters, because do not add anything sufficient to data
        #maybe in the future, don't accept tokens less than 3 characters anyways, will figure out later
        #important not to crash if a character within the line is not utf-8, must gracefully skip exceptions
        alpha_numeric_sequence_match = alphaNumericRegex.findall(line)
        #print(alpha_numeric_sequence_match)
        for sequence in alpha_numeric_sequence_match:
            tokenlist.append(sequence.lower())

    #close file now that it has 'successfully' been read and tokenized
    if(f != None):
        f.close()

    #return list
    return tokenlist

#computeWordFrequencies complexity is proportional to the length of it's token_list input, O(n)
def computeWordFrequencies(token_list):
    #create dictionary
    token_dict ={}
    #for every token in token_list, iterate count in the dictionary for the given token when found in list
    for token in token_list:
        if token_dict.get(token) != None:
            token_dict[token] +=1
        else:
            token_dict[token] = 1
    return token_dict

def incrementWordFrequencies(token_list, token_dict): #dictionary to modify is given
    global default_english_stop_list

    #for every token in token_list, iterate count in the dictionary for the given token when found in list
    # as long as word is not in the default_english_stop word list and token greater than 3 characters
    for token in token_list:
        if token.lower() not in default_english_stop_list and len(token) > 3:
            if token_dict.get(token.lower()) != None:
                token_dict[token.lower()] +=1
            else:
                token_dict[token.lower()] = 1
    return token_dict

#printFrequencies() complexity is tied to two main portions of the method
#the method both copies all map elements into a list, sorts that list, then prints the entire list
#since every element of the map/list is printed, assuming an efficient sort is used, then the complexity of the method
#is linearly proportional to the number of elements in the map, O(n)
def printFrequencies(token_map):
    #use python list comprehension to copy dictionary input into a list of tuples
    token_frequency_temp_list = []
    for key,value in token_map.items():
        token_frequency_temp_list.append((-value,key)) #swap value and key to make sorting easier later, tuples are (frequency,word)
        #use negative value here, so that sort will sort by descending frequency, but still ascending alphabetically when ties are made
        #just make sure to print absolute value of frequency later

    #sort list of tuples primarily by first index (word frequency) then alternatively by second index (token alphabetical)
    #token_frequency_temp_list = sorted(token_frequency_temp_list, key=lambda x: (x[0], x[1]))
    token_frequency_temp_list = sorted(token_frequency_temp_list)

    #print the sorted list out in style of <token> = <freq>
    for tuple in token_frequency_temp_list:
        print(tuple[1], " = ", abs(tuple[0]))
        #prints absolute value of token frequency to allow for easier sorting earlier


#if file is empty and can be opened, nothing is printed
if __name__ == '__main__':
    #some prerequisite checking command line arguments, assuming anything other than a single argument is invalid/error
    if(len(sys.argv) != 2):
        print('INVALID USAGE of command', str(sys.argv[0]))
        print(str(sys.argv[0]), '[VALID_File_Path]')
        exit(0)
    else:
        #valid number of arguments, continue processing
        file_path = str(sys.argv[1]) #keep track of command line argument, used as input filepath
        tokenlist = tokenize(file_path)
        tokendict = computeWordFrequencies(tokenlist)
        printFrequencies(tokendict)


