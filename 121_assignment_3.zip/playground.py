import os
import json
import partA
import math
import re
from bs4 import BeautifulSoup
from urllib.parse import urldefrag

def ParseDocIDList(filepath):
    d = []
    # Opening file
    file1 = open(filepath, 'r')
    for line in file1:
        d.append(line.strip())

    file1.close()
    return d

def ConvertFreqToLogTermFreq(tok_freq):
    if tok_freq <= 0:
        return 0
    return 1 + math.log10(tok_freq)

'''
    Input
        'query_tokens': a list of tokens from a given query
        'idf_ref': a dictionary created from ParseIDF_REF(), represents key,value of token:IDF value
    Return
        a dictionary with key value pairs token:LTC weighted value of token in query and index (log tok freq in query* idf of index)
'''
def constructLTCQueryVector(query_tokens, idf_ref):
    token_frequencies = partA.computeWordFrequencies(query_tokens)
    # this step pre-normalizes the tf weight of each document as its posting is being added

    #dictionary to be returned
    normalized_TLC_query_dict = {}

    # query length
    query_tf_idf_weight_length = 0
    for token, info in token_frequencies.items():
        # sum up the squared tf-idf weights
        curr_idf = 0
        if token in idf_ref:
            curr_idf = idf_ref[token]
        query_tf_idf_weight_length += ((ConvertFreqToLogTermFreq(info)*curr_idf) ** 2)

    # now doc_tf_weight_length now represents the length of the document tf weight vector
    query_tf_idf_weight_length = math.sqrt(query_tf_idf_weight_length)

    for token, info in token_frequencies.items():
        curr_idf = 0
        if token in idf_ref:
            curr_idf = idf_ref[token]
        normalized_TLC_query_dict[token] =  (ConvertFreqToLogTermFreq(info)*curr_idf) / query_tf_idf_weight_length

    return normalized_TLC_query_dict

'''
    Input
        'query_vector': a dictionary representing key,value pairs of query_token:normalizedtf*idf, using the ltc standard for query vector
        'INDEXOFINDEX': dictionary structure of index of index
        'DOCIDLIST': list representing dociD and accompanying url
    Return
        a list of urls that represent documents that contained at least one token in the query, ranked by relevance score 
        relevance score calculated by the cos dot product of each document to the given query vector
'''
def CosQueryMatch(query_vector, INDEXOFINDEX,DOCIDLIST):
    d = {}
    #initial set of documents for first query token added to dictionary
    outputfile = open('finalIndex.txt', 'r')

    #some redundant work here, will optimize later
    for tok,ltc_wt in query_vector:
        if tok not in INDEXOFINDEX:
            continue
        placement = int(INDEXOFINDEX[tok])
        outputfile.seek((placement))

        tokendocs = ParseIndexLineD(outputfile.readline())
        for docid,lnc_wt in tokendocs[1].items():
            if d.get(docid) == None:
                d[docid] = 0
            d[docid] += lnc_wt*ltc_wt


    #compute and sort list of tuples (relevance_score,docID)
    scores = [(relevance,did) for relevance,did in d.items()]
    scores.sort(reverse=True)

    return [DOCIDLIST[int(docID[1])] for docID in scores]

'''
    Input
        'filepath': a filepath that should point to a txt file created by BUILDINDEX that represents the reference of token to its IDF (inverted document freq)
    Return
        a dictionary with key value pairs token:IDF value based on full index
'''
def ParseIDF_REF(filepath):
    d = {}
    # Opening file
    file1 = open(filepath, 'r')
    for line in file1:
        templist = string_tokenize_include_period(line)
        d[templist[0]] = float(templist[1])

    file1.close()
    return d

def ParseIndexLineD(s):
    #TODO note may need to change parse algorithm when more statistics are added to index
    #postinglinecomponents = partA.string_tokenize(s)
    postinglinecomponents = string_tokenize_include_period(s)
    t = postinglinecomponents[0] #assuming first item is the token itself
    d = {}
    for i in range(1,len(postinglinecomponents),2):
        if d.get(postinglinecomponents[i]) == None:
            d[postinglinecomponents[i]] = 0
        d[postinglinecomponents[i]] = (postinglinecomponents[i+1])
    return (t,d)

'''
    Input
        'filepath': a filepath that should point to a txt file created by BUILDINDEX that represents the fully constructed index finalIndex.txt
        'tot_num_docs': an int value representing the total number of documents in the index
    Return
        NONE
        However, creates a IDF_REF.txt auxilliary file that will be used to look-up tokens and their associated IDF values based on the fully constructed index
'''
def CreateIDF_REF(filepath, tot_num_docs):
    finalindex = open(filepath,'r')
    with open('IDF_REF.txt', 'w') as outputfile:
        # idea, once index is fully built, read the index with readline and use tell after each call to get the starting index of each line
        for line in finalindex:
            templist = string_tokenize_include_period(line)
            #templist[0] is token of given line
            if (len(templist) <= 0):
                pass

            #might be kind of dodgy, but making assumption that a given posting list that has been tokenized
            #will be odd (1 tok for the actual token, and +2 for each pair of (docID, frequency)), so the lower floor of dividing by 2 will give the count of
            #documents with the given token
            count = int(len(templist)/2)
            idf = math.log10(tot_num_docs/count)

            outputfile.write('%s : %d\n' % (templist[0], idf))
    finalindex.close()

def string_tokenize_include_period(s):
    tokenlist = []
    alphaNumericRegex = re.compile(r"[a-zA-Z0-9\.]+")
    for line in s.splitlines():
        alpha_numeric_sequence_match = alphaNumericRegex.findall(line)
        #print(alpha_numeric_sequence_match)
        for sequence in alpha_numeric_sequence_match:
            tokenlist.append(sequence.lower())
    return tokenlist

def ConvertFreqToLogTermFreq(tok_freq):
    if tok_freq <= 0:
        return 0
    return 1 + math.log10(tok_freq)

def ParseIndexLine(s):
    #TODO note may need to change parse algorithm when more statistics are added to index
    postinglinecomponents = partA.string_tokenize(s)
    t = postinglinecomponents[0] #assuming first item is the token itself
    d = {}
    for i in range(1,len(postinglinecomponents),2):
        if d.get(postinglinecomponents[i]) == None:
            d[postinglinecomponents[i]] = list()
        d[postinglinecomponents[i]].append(postinglinecomponents[i+1])
    return (t,d)

def ParseIndexOfIndex(filepath):
    d = {}
    # Opening file
    file1 = open(filepath, 'r')
    for line in file1:
        templist = partA.string_tokenize(line)
        d[templist[0]] = templist[1]

    file1.close()
    return d

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    s = '<html xmlns="http://www.w3.org/1999/xhtml"><head><title> cs222p-2017-fall-project1-description (diff) – Public </title><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><link rel="search" href="/wiki/public/search"><link rel="help" href="/wiki/public/wiki/TracGuide"><link rel="up" href="/wiki/public/wiki/cs222p-2017-fall-project1-description?action=history" title="Page history"><link rel="next" href="/wiki/public/wiki/cs222p-2017-fall-project1-description?action=diff&version=12" title="Version 12"><link rel="start" href="/wiki/public/wiki"><link rel="stylesheet" href="/wiki/public/chrome/common/css/trac.css" type="text/css"><link rel="stylesheet" href="/wiki/public/chrome/common/css/wiki.css" type="text/css"><link rel="stylesheet" href="/wiki/public/chrome/common/css/diff.css" type="text/css"><link rel="stylesheet" href="/wiki/public/chrome/tracwysiwyg/wysiwyg.css" type="text/css"><link rel="tracwysiwyg.stylesheet" href="/wiki/public/chrome/common/css/trac.css"><link rel="tracwysiwyg.stylesheet" href="/wiki/public/chrome/tracwysiwyg/editor.css"><link rel="tracwysiwyg.base" href="/wiki/public"><link rel="prev" href="/wiki/public/wiki/cs222p-2017-fall-project1-description?action=diff&version=10" title="Version 10"><link rel="shortcut icon" href="/wiki/public/chrome/site/favicon.ico" type="image/x-icon"><link rel="icon" href="/wiki/public/chrome/site/favicon.ico" type="image/x-icon"><script type="text/javascript">;var _tracwysiwyg={};</script><script type="text/javascript" charset="utf-8" src="/wiki/public/chrome/common/js/jquery.js"></script><script type="text/javascript" charset="utf-8" src="/wiki/public/chrome/common/js/babel.js"></script><script type="text/javascript" charset="utf-8" src="/wiki/public/chrome/common/js/trac.js"></script><script type="text/javascript" charset="utf-8" src="/wiki/public/chrome/common/js/search.js"></script><script type="text/javascript" charset="utf-8" src="/wiki/public/chrome/common/js/diff.js"></script><script type="text/javascript" charset="utf-8" src="/wiki/public/chrome/tracwysiwyg/wysiwyg.js"></script><script type="text/javascript">;jQuery('#trac-noscript').remove();jQuery(document).ready(function(t){t('.trac-autofocus').focus();t('.trac-target-new').attr('target','_blank');setTimeout(function(){t('.trac-scroll').scrollToTop()},1);t('.trac-disable-on-submit').disableOnSubmit()});</script><link rel="stylesheet" type="text/css" href="/wiki/public/chrome/common/css/diff.css"><meta name="ROBOTS" content="NOINDEX, NOFOLLOW"></head><body><div id="banner"><div id="header"><a id="logo" href="http://www.ics.uci.edu/"><img src="/wiki/public/chrome/site/ics.jpg" alt="ICS Logo" height="67" width="128"></a></div><form id="search" action="/wiki/public/search" method="get"></form><div id="metanav" class="nav"><ul><li class="first"><a href="/wiki/public/login">Login</a></li><li><a href="/wiki/public/prefs">Preferences</a></li><li class="last"><a href="/wiki/public/about">About Trac</a></li></ul></div></div><div id="mainnav" class="nav"></div><div id="main"><div id="ctxtnav" class="nav"><h2>Context Navigation</h2><ul><li class="first"><span>← <a class="prev" href="/wiki/public/wiki/cs222p-2017-fall-project1-description?action=diff&version=10" title="Version 10">Previous Change</a></span></li><li><a href="/wiki/public/wiki/cs222p-2017-fall-project1-description?action=history" title="Page history">Wiki History</a></li><li class="last"><span><a class="next" href="/wiki/public/wiki/cs222p-2017-fall-project1-description?action=diff&version=12" title="Version 12">Next Change</a> →</span></li></ul><hr></div><div id="content" class="wiki"><h1> Changes between <a href="/wiki/public/wiki/cs222p-2017-fall-project1-description?version=10">Version 10</a> and <a href="/wiki/public/wiki/cs222p-2017-fall-project1-description?version=11">Version 11</a> of <a href="/wiki/public/wiki/cs222p-2017-fall-project1-description">cs222p-2017-fall-project1-description</a></h1><form method="post" id="prefs" action="/wiki/public/wiki/cs222p-2017-fall-project1-description?version=11"><div><input type="hidden" name="__FORM_TOKEN" value="6c1565efdab7e49a1d96697e"></div><div><input type="hidden" name="action" value="diff"><input type="hidden" name="version" value="11"><input type="hidden" name="old_version" value="10"><label for="style">View differences</label><select id="style" name="style"><option selected="selected" value="inline">inline</option><option value="sidebyside">side by side</option></select><div class="field"><label><input type="radio" name="contextall" value="0" checked="checked"> Show</label><label><input type="text" name="contextlines" id="contextlines" size="2" maxlength="3" value="2"> lines around each change</label><br><label><input type="radio" name="contextall" value="1"> Show the changes in full context</label></div><fieldset id="ignore"><legend>Ignore:</legend><div class="field"><input type="checkbox" id="ignoreblanklines" name="ignoreblanklines"><label for="ignoreblanklines">Blank lines</label></div><div class="field"><input type="checkbox" id="ignorecase" name="ignorecase"><label for="ignorecase">Case changes</label></div><div class="field"><input type="checkbox" id="ignorewhitespace" name="ignorewhitespace"><label for="ignorewhitespace">White space changes</label></div></fieldset><div class="buttons"><input type="submit" name="update" value="Update"></div></div></form><dl id="overview"><dt class="property time">Timestamp:</dt><dd class="time"> Oct 5, 2017 10:34:39 AM (<a class="timeline" href="/wiki/public/timeline?from=2017-10-05T10%3A34%3A39-07%3A00&precision=second" title="See timeline at Oct 5, 2017 10:34:39 AM">5 years</a> ago) </dd><dt class="property author">Author:</dt><dd class="author"> cluo8 </dd><dt class="property message">Comment:</dt><dd class="message"><p> -- </p></dd></dl><div class="diff"><div class="legend" id="diff-legend"><h3>Legend:</h3><dl><dt class="unmod"></dt><dd>Unmodified</dd><dt class="add"></dt><dd>Added</dd><dt class="rem"></dt><dd>Removed</dd><dt class="mod"></dt><dd>Modified</dd></dl></div><div class="diff"><ul class="entries"><li class="entry"><h2 id="file0"><span class="switch"><span class="active">Tabular</span><span>Unified</span></span><a href="/wiki/public/wiki/cs222p-2017-fall-project1-description?version=11">cs222p-2017-fall-project1-description</a></h2><table class="trac-diff inline" summary="Differences" cellspacing="0"><colgroup><col class="lineno"><col class="lineno"><col class="content"></colgroup><thead><tr><th title="Version 10"><a href="/wiki/public/wiki/cs222p-2017-fall-project1-description?version=10#L53"> v10</a></th><th title="Version 11"><a href="/wiki/public/wiki/cs222p-2017-fall-project1-description?version=11#L53"> v11</a></th><td> </td></tr></thead><tbody class="unmod"><tr><th>53</th><th>53</th><td class="l"><span></span></td></tr><tr><th>54</th><th>54</th><td class="l"><span>=== RC openFile (const string &fileName, !FileHandle &fileHandle) ===</span></td></tr></tbody><tbody class="mod"><tr class="first"><th>55</th><th> </th><td class="l"><span>This method opens the paged file whose name is fileName. The file must already exist (and been created using the createFile method). If the open method is successful, the fileHandle object whose address is passed in as a parameter now becomes a "handle" for the open file. This file handle is used to manipulate the pages of the file (see the<del> !FileHandle class description below). It is an error if fileHandle is already a handle for some open file when it is passed to the openFile method. It is not an error to open the same file more than once if desired, but this would be done by using a different fileHandle object each time. Each call to the openFile method creates a new "instance" of the open fi</del>le. Warning: Opening a file more than once for data modification is not prevented by the PF component, but doing so is likely to corrupt the file structure and may crash the PF component. (You do not need to try and prevent this, as you can assume the layer above is "friendly" in that regard.) Opening a file more than once for reading is no problem.</span></td></tr><tr class="last"><th> </th><th>55</th><td class="r"><span>This method opens the paged file whose name is fileName. The file must already exist (and been created using the createFile method). If the open method is successful, the fileHandle object whose address is passed in as a parameter now becomes a "handle" for the open file. This file handle is used to manipulate the pages of the file (see the<ins> FileHandle class description below). It is an error if fileHandle is already a handle for some open file when it is passed to the openFile method. It is not an error to open the same file more than once if desired, but this would be done by using a different fileHandle object each time. Each call to the openFile method creates a new "instance" of FileHand</ins>le. Warning: Opening a file more than once for data modification is not prevented by the PF component, but doing so is likely to corrupt the file structure and may crash the PF component. (You do not need to try and prevent this, as you can assume the layer above is "friendly" in that regard.) Opening a file more than once for reading is no problem.</span></td></tr></tbody><tbody class="unmod"><tr><th>56</th><th>56</th><td class="l"><span></span></td></tr><tr><th>57</th><th>57</th><td class="l"><span>=== RC closeFile (!FileHandle &fileHandle) ===</span></td></tr></tbody></table><pre class="diff" style="display:none"></pre></li></ul></div></div></div></div><div id="footer" lang="en" xml:lang="en"><hr><a id="tracpowered" href="http://trac.edgewall.org/"><img src="/wiki/public/chrome/common/trac_logo_mini.png" height="30" width="107" alt="Trac Powered"></a><p class="left">Powered by <a href="/wiki/public/about"><strong>Trac 1.0.13</strong></a><br> By <a href="http://www.edgewall.org/">Edgewall Software</a>.</p><p class="right">Visit the Trac open source project at<br><a href="http://trac.edgewall.org/">http://trac.edgewall.org/</a></p></div></body></html>'
    soup = BeautifulSoup(s, 'lxml')

    # TODO TEST OPTIMIZATION, REMOVE TEXT FROM LINKS
    for a in soup.findAll('a',href = True):
        a.extract()

    # tokenizes content of page
    text = soup.get_text()

    print(text)

    #print(urldefrag('https://www.informatics.uci.edu/impact/undergraduate-alumni-spotlights/johnny-thoi/#content')[0])

    '''
    DOCIDS = ParseDocIDList('DOCIDREFERENCE.txt')
    Index_of_Index = ParseIndexOfIndex('INDEXOFINDEX.txt')
    IDF_REF = ParseIDF_REF('IDF_REF.txt')

    Index = {}
    f = open("C:\\Python38\\121_assignment_3\\DEV\\chenli_ics_uci_edu\\eafdaf9ec09292e18bdedf243607f01545ba3fef9b75181728a95bb25ddd33d4.json")
    currdoc = json.load(f)

    soup = BeautifulSoup(currdoc['content'], 'lxml')

    # tokenizes content of page
    text = soup.get_text()
    token_list = partA.string_tokenize(text)
    token_frequencies = partA.computeWordFrequencies(token_list)

    # this step pre-normalizes the tf weight of each document as its posting is being added
    # document length
    doc_tf_weight_length = 0
    for token, info in token_frequencies.items():
        # sum up the squared tf weights
        doc_tf_weight_length += (ConvertFreqToLogTermFreq(info) ** 2)
    # now doc_tf_weight_length now represents the length of the document tf weight vector
    doc_tf_weight_length = math.sqrt(doc_tf_weight_length)

    for token, info in token_frequencies.items():

        # info transformed into log term freqency/ length of the entire document weights, normalized to optimize for cosine
        # similarity later on
        Index[token]= (ConvertFreqToLogTermFreq(info)) / doc_tf_weight_length

    print(Index)
    sum = 0.0
    for k,i in Index.items():
        sum+= i**2
    print(sum)
    print(math.sqrt(sum))

    #currently Index is the document vector for whatever this chenli doc is
    #TODO check cosine similarity working or not

    query_vector = constructLTCQueryVector(['chen','li'], IDF_REF)
    print(query_vector)

    score = 0

    for tok,ltc_wt in query_vector.items():
        if tok not in Index_of_Index:
            continue

        for docid,lnc_wt in Index.items():
            if tok == docid:
                score += float(lnc_wt)*ltc_wt


    #compute and sort list of tuples (relevance_score,docID)
    print(score)
    '''



    '''
    
    idf1 ={'auto': 2.3, 'best':1.3,'car':2.0}
    tmpqueryvec = constructLTCQueryVector(['best','car','insurance'],idf1)
    print(tmpqueryvec)
    '''




    '''
    tmpfile = open('thisisatest.txt', 'r+')
    line = tmpfile.readline().strip()
    print(line)
    line = tmpfile.readline()
    print(line)

    line = tmpfile.readline()
    while line:
        print(line)
        line = tmpfile.readline()

    tmpfile.close()
    '''



    '''
    #code for creating index of index from already fully created index
    Index_of_Index = {}
    file1 = open('tempIndex.txt', 'r')
    tmploc = file1.tell()
    line = file1.readline()
    templist = partA.string_tokenize(line)
    Index_of_Index[templist[0]] = tmploc
    while line:
        tmploc = file1.tell()
        line = file1.readline()
        templist = partA.string_tokenize(line)
        if(len(templist) > 0):
            Index_of_Index[templist[0]] = tmploc
    file1.close()

    print(Index_of_Index)
    '''



    #Index_of_Index = ParseIndexOfIndex('INDEXOFINDEX.txt')
    #unique_pages_list = [('test',0),('whack',0),('you',5)]
    '''
        with open('thisisatest.txt', 'w') as outputfile:
        for element in unique_pages_list:
            # also write token locations in this index file to the INDEX OF INDEX file for faster look-up
            # todo this implementation must be changed when batch files are used to merge indexes
            Index_of_Index[element[0]] = outputfile.tell()

            outputfile.write('%s : ' % element[0])

            outputfile.write('\n')

    print(Index_of_Index)

    # print Index_of_Index to auxillaary file
    with open('INDEXOFINDEX.txt', 'w') as outputfile:
        for k, v in Index_of_Index.items():
            outputfile.write('%s : %d\n' % (k, v))
        outputfile.close()
    '''



    ''''
        outputfile = open('thisisatest.txt', 'r')

    placement = int(Index_of_Index['whack'])
    outputfile.seek((placement))
    print(outputfile.readline())
    '''


    '''
    #path = "./ANALYST"
    path = "./DEV"

    f = open("C:\\Python38\\121_assignment_3\DEV\cbcl_ics_uci_edu\\00ac1c9773db5832e9922f6eca825c251de03d6195cdb9efa9906ec5823835ef.json")
    data = json.load(f)
    soup = BeautifulSoup(data['content'], 'lxml')

    # tokenizes content of page
    text = soup.get_text()
    token_list = partA.string_tokenize(text)
    token_frequencies = partA.computeWordFrequencies(token_list)
    print(token_frequencies)

    test = 'test&yes'


    print(partA.string_tokenize(test))
    '''


'''
    sum =0


    for root, d_names, f_names in os.walk(path):
        #print(root, d_names, f_names)
        for filename in f_names:
            sum+=1
            #temppath = os.path.join(root,filename) #this might be a little wonky on other machines?
            #print(temppath)
            #f = open(temppath)
            #data = json.load(f)
            #print(data['url'])




    print(sum)
'''


