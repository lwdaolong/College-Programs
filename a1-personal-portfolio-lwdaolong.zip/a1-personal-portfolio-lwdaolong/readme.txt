--Readme document for *author*-- Logan Wang

A reminder on academic integrity, as described in the syllabus.

In general, the course staff expects that you will look at code and examples from many online resources as part of the assignments, particularly to resolve syntax and understand frameworks. We expect that you'll use other libraries you find, and will even require it in some assignments. These practices are often critical to the work of developers today. The best developers are adept at interpreting the examples they see, customizing them to their specific situation, and citing their sources so they can find them later. We expect you to do the same.

While learning from examples is encouraged, attempting to pass an existing project or example from the web as your own is not allowed. If you ever have a question about what is or is not appropriate, feel free to ask the course staff!

Talking to classmates about class material, assignment requirements, etc. is a great way to verify ideas and get feedback. But this distinctly does *not* permit attempting to pass off someone else’s code as your own. Talking over ideas and approaches is allowed, but the work that you produce and submit must be your own.

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

13/14
- 1/1 Readme
- 3/3 Basic HTML content
- 3/3 Basic CSS styling
- 1/1 Advanced feature
- 3/3 Responsive layout
- 1/1 Passes validation checks
- 1/2 Embraces spirit of the assignment

2. What (a) basic features, (b) CSS features, and (c) advanced features did you include in your portfolio?

(a) Basic features
	I included multiple images with descriptive alt text
	I included appropriate headings and paragraph text
	I included links to other external pages like linkedin and Github
	I included multiple pages to navigate between on the site
	I used semantic tags like footer
	I used custom icons from Feather to add some style to my page
		also made buttons out of the icons


(b) CSS features
	Utilized Bootstrap and a lot of its responsive design functionality with the grid system to ensure responsiveness
	I modified padding of paragraph text to ensure no overlap of text and easy reading
		Also modified margins to allow for fixed menus to not cover important text
		Different margins for different screen sizes
	I modified text color and background colors to create an enjoyable viewing experience, along with acessible contrast
	I used Bootstrap to make a 2 column design for large screens, and a stacked design for smaller screens
	I also used Bootsraps shapes to fit images into circles and rounded rectangles
	I added custom Google fonts to help my page not feel like a typical Bootstrap page and add my own twist	


(c) Advanced features
	With the help of Bootstrap's documentation, I modified a responsive navigation menu that is fixed to the top of the screen
	Also with the help of Bootstrap's documentation, I created an html form to contact me.



3. How long, in hours, did it take you to complete this assignment?
	About 12 hours, lots of research on tags and techniques was necessary


4. What online resources did you consult when completing this assignment? (list specific URLs)
	Lots of site documentation, mostly Bootstrap.
	https://mdbootstrap.com/docs/b4/jquery/forms/contact/
	https://getbootstrap.com/docs/4.0/components/navbar/
	https://github.com/feathericons/feather#feather


5. What classmates or other individuals did you consult as part of this assignment? What did you discuss?
	None


6. Is there anything special we need to know in order to run your code?
	None
