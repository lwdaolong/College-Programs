function parseTweets(runkeeper_tweets) {
	//Do not proceed if no tweets loaded
	if(runkeeper_tweets === undefined) {
		window.alert('No tweets returned');
		return;
	}

	tweet_array = runkeeper_tweets.map(function(tweet) {
		return new Tweet(tweet.text, tweet.created_at);
	});

    //Find earliest and latest tweet
	var minDate = tweet_array[0].time;
	var maxDate = tweet_array[0].time;
	const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };

    var tot_tweets = tweet_array.length+1
    var num_completed_events =0;
    var num_completed_events_written = 0;
    var num_live_events = 0;
    var num_achievements = 0;
    var num_misc = 0;

    console.log(tweet_array[0].time.getUTCDate());

	for(let i =0; i < tweet_array.length;i++){
	    //for debugging
	    //console.log(tweet_array[i].activityType)
	    //console.log(tweet_array[i].distance)
	    if(tweet_array[i].written){
	        //console.log(tweet_array[i].writtenText);
	    }

        if(tweet_array[i].source == "completed_event"){
            num_completed_events +=1;
            if(tweet_array[i].written){
                num_completed_events_written +=1
            }
        }
        if(tweet_array[i].source == "live_event"){
            num_live_events +=1;
        }
        if(tweet_array[i].source == "achievement"){
            num_achievements +=1;
        }
        if(tweet_array[i].source == "miscellaneous"){
            num_misc +=1;
        }

	    if(tweet_array[i].time <minDate){
	        minDate = tweet_array[i].time;
	    }
	    if(tweet_array[i].time > maxDate){
	        maxDate = tweet_array[i].time;
	    }
	}

    console.log(maxDate);
    console.log(minDate);

    document.getElementById('firstDate').innerText = (minDate.toLocaleDateString(undefined,options));
    document.getElementById('lastDate').innerText = (maxDate.toLocaleDateString(undefined,options));

	//This line modifies the DOM, searching for the tag with the numberTweets ID and updating the text.
	//It works correctly, your task is to update the text of the other tags in the HTML file!
	document.getElementById('numberTweets').innerText = tweet_array.length;

	document.getElementsByClassName('completedEvents')[0].innerText = num_completed_events;
	document.getElementsByClassName('liveEvents')[0].innerText = num_live_events;
	document.getElementsByClassName('achievements')[0].innerText = num_achievements;
	document.getElementsByClassName('miscellaneous')[0].innerText = num_misc;

	document.getElementsByClassName('completedEventsPct')[0].innerText = math.format(num_completed_events/tot_tweets, {notation: 'fixed', precision: 2});
	document.getElementsByClassName('liveEventsPct')[0].innerText = math.format(num_live_events/tot_tweets, {notation: 'fixed', precision: 2});
	document.getElementsByClassName('achievementsPct')[0].innerText = math.format(num_achievements/tot_tweets, {notation: 'fixed', precision: 2});
	document.getElementsByClassName('miscellaneousPct')[0].innerText = math.format(num_misc/tot_tweets, {notation: 'fixed', precision: 2});

	document.getElementsByClassName('completedEvents')[1].innerText = num_completed_events;
	document.getElementsByClassName('written')[0].innerText = num_completed_events_written;
	document.getElementsByClassName('writtenPct')[0].innerText = math.format(num_completed_events_written/num_completed_events, {notation: 'fixed', precision: 2});

}

//Wait for the DOM to load
document.addEventListener('DOMContentLoaded', function (event) {
	loadSavedRunkeeperTweets().then(parseTweets);
});