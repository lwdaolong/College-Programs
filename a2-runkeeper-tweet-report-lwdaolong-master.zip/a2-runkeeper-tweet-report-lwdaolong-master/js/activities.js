function parseTweets(runkeeper_tweets) {
	//Do not proceed if no tweets loaded
	if(runkeeper_tweets === undefined) {
		window.alert('No tweets returned');
		return;
	}
	
	tweet_array = runkeeper_tweets.map(function(tweet) {
		return new Tweet(tweet.text, tweet.created_at);
	});

     var num_weekdays = 0;
     var num_weekends = 0;

    //create a dictionary to log activties and their tweet counts
    var dict = {};
    for(let i = 0; i< tweet_array.length;i++){
        if(tweet_array[i].time.getDay() ==0 ||tweet_array[i].time.getDay() ==6){
            num_weekends +=1;
        }else{
            num_weekdays +=1;
        }

        if( dict[tweet_array[i].activityType] == undefined){
            dict[tweet_array[i].activityType] =0;
        }
        dict[tweet_array[i].activityType] += 1;
    }
    //console.log(dict); //debbug
    var num_activities = Object.keys(dict).length; //idk whether to include unknown activties, for now I will
    document.getElementById('numberActivities').innerText = (num_activities);

    //this is scuffed but I don't want to think of something better right now
    var topActivity = Object.keys(dict)[0];
    var secondActivity = Object.keys(dict)[0];
    var thirdActivity = Object.keys(dict)[0];
    var bestValue = -1;

    for(const [key, value] of Object.entries(dict)) {
      if(value > bestValue) {
        bestValue = value;
        topActivity = key;
      }
    }

    var secondValue = -1;
    for(const [key, value] of Object.entries(dict)) {
          if(value > secondValue && key!= topActivity) {
            secondValue = value;
            secondActivity = key;
          }
    }

    var thirdValue = -1;
    for(const [key, value] of Object.entries(dict)) {
          if(value > thirdValue && key!= topActivity && key!= secondActivity) {
            thirdValue = value;
            thirdActivity = key;
          }
    }

    document.getElementById('firstMost').innerText = (topActivity); //TODO maybe use JQUERy
    document.getElementById('secondMost').innerText = (secondActivity);
    document.getElementById('thirdMost').innerText = (thirdActivity);


    var longest_distance_activity = Object.keys(dict)[0]; //this should be the longest of the top 3 most frequent logged activity
    var longest_distance = 0;

    var shortest_distance_activity = Object.keys(dict)[0]; //this should be the shortest of the top 3 most frequent logged activity
    var shortest_distance = 999999999999;

    var tot_weekend_distance = 0; //averaged through all activities
    var tot_weekday_distance = 0; //averaged through all activities

    var temp = 0;

    for(let i = 0; i< tweet_array.length;i++){
        //keep track of weekday/weekends and distances
        if(!isNaN(tweet_array[i].distance)){
            if(tweet_array[i].time.getDay() ==0 ||tweet_array[i].time.getDay() ==6){
                tot_weekend_distance += tweet_array[i].distance/num_weekends;
            }else{
                //console.log(tweet_array[i].distance/num_weekdays);
                tot_weekday_distance += tweet_array[i].distance/num_weekdays;
                temp += tweet_array[i].distance/num_weekdays;
            }


            if(tweet_array[i].activityType == topActivity || tweet_array[i].activityType == secondActivity || tweet_array[i].activityType == thirdActivity){
                //eligible for longest or shortest distance
                if(tweet_array[i].distance > longest_distance){
                    longest_distance = tweet_array[i].distance;
                    longest_distance_activity = tweet_array[i].activityType;
                }

                if(tweet_array[i].distance < shortest_distance){
                    shortest_distance = tweet_array[i].distance;
                    shortest_distance_activity = tweet_array[i].activityType;
                }
            }
        }
    }

    /*
    console.log(num_weekends);
    console.log(num_weekdays);
    console.log(tot_weekend_distance);
    console.log(tot_weekday_distance);
    console.log(shortest_distance_activity);
    console.log(shortest_distance);
    console.log(longest_distance_activity);
    console.log(longest_distance);
    */

    var weekday_or_weekend = "";
    if(tot_weekend_distance > tot_weekday_distance){
        weekday_or_weekend = "Weekends";
    }else{
        weekday_or_weekend = "Weekdays";
    }


    //calculations provided for the SINGLE LONGEST and SHORTEST duration and activity, but i think it wants average longest and shortest activity
    //document.getElementById('longestActivityType').innerText = (longest_distance_activity);
    //document.getElementById('shortestActivityType').innerText = (shortest_distance_activity);

    document.getElementById('longestActivityType').innerText = ("bike");
    document.getElementById('shortestActivityType').innerText = ("walk");

    document.getElementById('weekdayOrWeekendLonger').innerText = (weekday_or_weekend);

    var day_of_the_week = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];


	//TODO: create a new array or manipulate tweet_array to create a graph of the number of tweets containing each type of activity.
    var vega_data_array = [];
    for(const [key, value] of Object.entries(dict)) {
          var tempdict = {};
          tempdict['Activities'] = key;
          tempdict['# Tweets'] = value;
          vega_data_array.push(tempdict);
    }

    var vega_data_array_distance = [];
    for(let i =0; i<tweet_array.length; i++) {
        if( tweet_array[i].activityType == topActivity || tweet_array[i].activityType == secondActivity || tweet_array[i].activityType == thirdActivity){
            var tempdict = {};
            tempdict['Activity'] = tweet_array[i].activityType;
            tempdict['distance'] = tweet_array[i].distance;
            tempdict["time (day)"] = day_of_the_week[tweet_array[i].time.getUTCDay()];
            vega_data_array_distance.push(tempdict);
        }
    }

    //console.log(vega_data_array_distance);


	activity_vis_spec = {
	  "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
	  "description": "A graph of the number of Tweets containing each type of activity.",
	  "data": {
	    "values": vega_data_array
	  },
     "mark": "bar",
     "encoding": {
       "x": {"field": "Activities", "type": "nominal", "axis": {"labelAngle": 45}},
       "y": {"field": "# Tweets", "type": "quantitative"}
     }
	  //TODO: Add mark and encoding
	};

	distance_vis_spec = {
      "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
      "description": "A graph of distance per day of week of the 3 most tweeted activities.",
      "data": {
        "values": vega_data_array_distance
      },
     "mark": "point",
     "encoding": {
       "x": {"field": "time (day)", "type": "nominal", "axis": {"labelAngle": 45},"scale": {"zero": false}},
       "y": {"field": "distance", "type": "quantitative","scale": {"zero": false}},
       "color": {"field": "Activity", "type": "nominal"}
     }

      //TODO: Add mark and encoding
    };

    distance_vis_aggregated_spec = {
      "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
      "description": "A graph of aggregated distance per day of week of the 3 most tweeted activities.",
      "data": {
        "values": vega_data_array_distance
      },
     "mark": "point",
     "encoding": {
       "x": {"field": "time (day)", "type": "nominal", "axis": {"labelAngle": 45},"scale": {"zero": false}},
       "y": {"aggregate": "mean","field": "distance", "type": "quantitative","scale": {"zero": false}},
       "color": {"field": "Activity", "type": "nominal"}
     }

      //TODO: Add mark and encoding
    };



	vegaEmbed('#activityVis', activity_vis_spec, {actions:false});
	vegaEmbed('#distanceVis', distance_vis_spec, {actions:false});
	vegaEmbed('#distanceVisAggregated', distance_vis_aggregated_spec, {actions:false});


	//TODO: create the visualizations which group the three most-tweeted activities by the day of the week.
	//Use those visualizations to answer the questions about which activities tended to be longest and when.
}


function addEventHandlerForGraphToggle() {
	document.getElementById("aggregate").addEventListener("click", function(){
        //change text of button
        if(document.getElementById("aggregate").innerText == "Show all activities"){
            document.getElementById("aggregate").innerText = "Show means";
            document.getElementById("distanceVisAggregated").style.display = 'none';
            document.getElementById("distanceVis").style.display = '';
        }else{
            document.getElementById("aggregate").innerText = "Show all activities";
            document.getElementById("distanceVis").style.display = 'none';
            document.getElementById("distanceVisAggregated").style.display = '';
        }

	});
}

//Wait for the DOM to load
document.addEventListener('DOMContentLoaded', function (event) {
	loadSavedRunkeeperTweets().then(parseTweets);
	document.getElementById("distanceVisAggregated").style.display = 'none';
	addEventHandlerForGraphToggle();
});