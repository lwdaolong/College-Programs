function parseTweets(runkeeper_tweets) {
	//Do not proceed if no tweets loaded
	if(runkeeper_tweets === undefined) {
		window.alert('No tweets returned');
		return;
	}

	tweet_array = runkeeper_tweets.map(function(tweet) {
        return new Tweet(tweet.text, tweet.created_at);
    });

    var written_tweets = [];
    for(let i= 0; i < tweet_array.length;i++){
        if(tweet_array[i].written){
            written_tweets.push(tweet_array[i]);
        }
    }

	//TODO: Filter to just the written tweets
    return written_tweets;
}

function addEventHandlerForSearch(written_tweets) {
	//TODO: Search the written tweets as text is entered into the search box, and add them to the table
	let tablebody = document.getElementById('tweetTable');


	document.getElementById("textFilter").addEventListener("input", function(){
	    //clear table after event
        while (tablebody.firstChild) {
                tablebody.removeChild(tablebody.firstChild);
        }


	    var input_text = document.getElementById("textFilter").value;
	    //console.log(input_text);
	    if(input_text == ""){
	        document.getElementById('searchText').innerText = "";
            document.getElementById('searchCount').innerText = 0;
	    }else{
	        //update spans and update tables
	        //idk how tables work yet, so will manually filter thru written texts on every update
	        var search_match_count =0;
	        var search_match_arr = [];
	        for(let i= 0; i < written_tweets.length;i++){
	            if(written_tweets[i].text.includes(input_text)){
                    search_match_count +=1;
                    search_match_arr.push(written_tweets[i]);

                    let temptweetRow = written_tweets[i].getHTMLTableRow(i);


                    //maybe add tweet to html table here
                    let tweetRow = document.createElement('tr');
                    tweetRow.className = 'tweetTableBodyRow';

                    //create the td elements
                    let tweetNum = document.createElement('td');
                    tweetNum.innerText = search_match_count;

                    let tweetActivity = document.createElement('td');
                    tweetActivity.innerText = written_tweets[i].activityType;

                    let tweetText = document.createElement('td');
                    //TODO change to clickable link
                    tweetText.innerHTML = written_tweets[i].getHTMLTableRow(i)

                    //put td's into tr, then append tr to table itself
                    tweetRow.append(tweetNum,tweetActivity,tweetText);

                    tablebody.append(tweetRow);
                    //tablebody.innerHTML +=(tweetRow);
	            }
            }
            document.getElementById('searchText').innerText = input_text;
            document.getElementById('searchCount').innerText = search_match_count;
	    }
	});
}

//Wait for the DOM to load
document.addEventListener('DOMContentLoaded', function (event) {
    //set initially to 0;
	document.getElementById('searchText').innerText = "";
    document.getElementById('searchCount').innerText = 0;

    //https://www.w3schools.com/js/js_promise.asp
	var written_tweets = loadSavedRunkeeperTweets().then(parseTweets); //idk how Promises work, but this is working? idk why this returned a promise
    written_tweets.then(
        function(value){
            addEventHandlerForSearch(value);
        },
        function(error){
            console.log(error);
        }
    );
});