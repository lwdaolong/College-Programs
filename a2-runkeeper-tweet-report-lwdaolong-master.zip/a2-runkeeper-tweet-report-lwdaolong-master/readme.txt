--Readme document for *author*-- Logan Wang

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

15/15
- 1/1 Tweet dates
- 1/1 Tweet categories
- 2/2 User-written tweets
- 3/3 Determining activity type and distance
- 3/3 Graphing activities by distance
- 2/2 Implementing the search box
- 3/3 Populating the table

2. How long, in hours, did it take you to complete this assignment?
	About 8 hours, mostly looking up documentation for graphing and html tables.


3. What online resources did you consult when completing this assignment? (list sites like StackOverflow or specific URLs for tutorials, etc.)
	Mostly documentation for vega-lite and javascript functions
	//https://www.w3schools.com/js/js_promise.asp	
	https://vega.github.io/vega-lite/docs/aggregate.html
	https://vega.github.io/editor/#/examples/vega-lite/point_color_with_shape
	stackoverflow.com/questions/3809401/what-is-a-good-regular-expression-to-match-a-url (modified regex from this post)
	



4. What classmates or other individuals did you consult as part of this assignment? What did you discuss?
	None


5. Is there anything special we need to know in order to run your code?
	For the activities.html page, I was confused whether longest and shortest distance meant literally the longest or shortest distance or the activity with the
	average longest and average shortest. I decided on average, but have code to switch to single instance of longest and shortest activity and duration if necessary.