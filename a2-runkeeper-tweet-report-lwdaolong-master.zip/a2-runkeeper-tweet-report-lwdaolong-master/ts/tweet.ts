class Tweet {
	private text:string;
	time:Date;

	constructor(tweet_text:string, tweet_time:string) {
        this.text = tweet_text;
		this.time = new Date(tweet_time);//, "ddd MMM D HH:mm:ss Z YYYY"
	}

	//returns either 'live_event', 'achievement', 'completed_event', or 'miscellaneous'
    get source():string {
        //TODO: identify whether the source is a live event, an achievement, a completed event, or miscellaneous.
        //should "posted" be considered a completed event?
        if(this.text.includes("completed") || this.text.includes("posted")){
            return "completed_event"
        }else if(this.text.includes("RKLive")){
            return "live_event"
        }else if(this.text.includes("Achieved")){
            return "achievement"
        }else{
            return "miscellaneous"
        }
        //return "unknown";
    }

    //returns a boolean, whether the text includes any content written by the person tweeting.
    get written():boolean {
        //TODO: identify whether the tweet is written
        if(this.text.includes("-") && !(this.text.includes("TomTom"))){
            return true;
        }//else
        return false;
    }

    get writtenText():string {
        if(this.written) {
            var start_index = this.text.indexOf("-");
            var end_index = this.text.indexOf("https");

            return this.text.substring(start_index+2,end_index);
        }
        //TODO: parse the written text from the tweet
        return "";
    }

    get activityType():string {
        if (this.source != 'completed_event') {
            return "unknown";
        }
        //TODO: parse the activity type from the text of the tweet
        if(this.text.indexOf(" mi ") >=0 && this.text.indexOf(" km ") >=0){
            if(this.text.indexOf(" mi ") < this.text.indexOf(" km ")){
                if(this.text.includes("-")){
                    //important that this comes first
                    return this.text.substring(this.text.indexOf("mi")+3,this.text.indexOf(" - "));
                }else if(this.text.includes("with")){
                    return this.text.substring(this.text.indexOf("mi")+3,this.text.indexOf(" with "));
                }
                return  "";
            }else{
                if(this.text.includes("-")){
                    //important that this comes first
                    return this.text.substring(this.text.indexOf("km")+3,this.text.indexOf(" - "));
                }else if(this.text.includes("with")){
                    return this.text.substring(this.text.indexOf("km")+3,this.text.indexOf(" with "));
                }
                return  "";

            }
        }else if(this.text.includes(" mi ")){
            if(this.text.includes("-")){
                //important that this comes first
                return this.text.substring(this.text.indexOf("mi")+3,this.text.indexOf(" - "));
            }else if(this.text.includes("with")){
                return this.text.substring(this.text.indexOf("mi")+3,this.text.indexOf(" with "));
            }
            return  "";
        }else if(this.text.includes(" km ")){
            if(this.text.includes("-")){
                //important that this comes first
                return this.text.substring(this.text.indexOf("km")+3,this.text.indexOf(" - "));
            }else if(this.text.includes("with")){
                return this.text.substring(this.text.indexOf("km")+3,this.text.indexOf(" with "));
            }
            return  "";
        }else{
             return "Non Time Duration"; //blank if cannot be parsed or is of time duration
        }
        //if in miles, find substring between miles and "with Runkeeper " or "-"
        //if in km, find substring between km and "with Runkeeper" or " - "
        //also option of no distance, might be duration, for the sake of assignment, not processing these activities

    }

    get distance():number {
        if(this.source != 'completed_event') {
            return 0;
        }
        //TODO: prase the distance from the text of the tweet
        if(this.text.indexOf(" mi ") >=0 && this.text.indexOf(" km ") >=0){
            if(this.text.indexOf(" mi ") < this.text.indexOf(" km ")){
                var tempreturn = +(this.text.substring(this.text.indexOf("a ")+2,this.text.indexOf(" mi ")));
            }else{
                var tmp_km =  +(this.text.substring(this.text.indexOf("a ")+2,this.text.indexOf(" km ")));
                return tmp_km/1.609;
            }
        }else if(this.text.includes(" mi ")){
        var tempreturn = +(this.text.substring(this.text.indexOf("a ")+2,this.text.indexOf(" mi ")));
        if(isNaN(tempreturn)){
            console.log(this.text);
            return 0;
        }
        return +(this.text.substring(this.text.indexOf("a ")+2,this.text.indexOf(" mi ")));
        }else if(this.text.includes(" km ")){
            var tmp_km =  +(this.text.substring(this.text.indexOf("a ")+2,this.text.indexOf(" km ")));
            if(isNaN(tmp_km)){
                console.log(this.text);
                return 0;
            }
            return tmp_km/1.609;
        }
        return 0;
    }

    getHTMLTableRow(rowNumber:number):string {
        //this is slow and clunky because of the way you add to table, instead will repurpose this to return text of tweet
        //made with html and <a href> embedded
        //TODO: return a table row which summarizes the tweet with a clickable link to the RunKeeper activity
        //console.log(`<tr><td> ${rowNumber} </td><td>${this.activityType}</td><td>${this.text}</td></tr>`);
        //regex modified from https://stackoverflow.com/questions/3809401/what-is-a-good-regular-expression-to-match-a-url
        const var_regex_temp = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=\/]{2,256}/;
        const url_regex = new RegExp(var_regex_temp);

        var url = this.text.match(url_regex)![0]; //scuffed using exclamation point as nonn null assertion operator

        if(this.text != null){
            if(this.text.match(url_regex) != null){

            }

        }


        //console.log(url);
        var url_start_index = this.text.indexOf(url); //index of first char in link
        var url_end_index = url_start_index + url.length - 1; //index of last char in link beware of fenceposting

        var string_before_link = this.text.substring(0,url_start_index);
        if(url_end_index+1 < this.text.length){
            var string_after_link =this.text.substring(url_end_index+1);
        }else{
            var string_after_link = "";
        }
        var final_string_with_embedded_link = string_before_link + '<a href = "' + url + '">' + url + "</a>" + string_after_link;
        //console.log(final_string_with_embedded_link);
        return final_string_with_embedded_link;
    }
}