import { Component, OnInit } from '@angular/core';

import { ProfileData } from '../../data/profile-data';
import { SpotifyService } from '../../services/spotify.service';




@Component({
  selector: 'app-playback',
  templateUrl: './playback.component.html',
  styleUrls: ['./playback.component.css']
})
export class PlaybackComponent implements OnInit {

    //TODO: inject the Spotify service
    constructor(private spotifyapi:SpotifyService) { }

    ngOnInit() {
       window.onSpotifyWebPlaybackSDKReady = () => {
         console.log('spotify script loaded');
         const token = 'BQBDTTx9g98yfmLuSuUpzdOTee4YwaBFx-u-JozzccYAynI8FZjNbUsLMnyWLI4P-2KR_I_2ds}ghgOCPVWBsW5tOs0YjyfbdiJr21JiH0rfvvSvnt_S9Ly0UJMoB6xY-mDsmF2HwqKn0WCFz3rl2ohSmtE2OGNRUo6WmF9GSFXIMCFFC1fWqUcpq7dzu38nniW0';
         const player = new Spotify.Player({
           name: 'test',
           getOAuthToken: () => {
             return token;
           },
         });
         player.connect().then((success) => console.log('Connected:', success));
       };
       const script = document.createElement('script');
       script.src = 'https://sdk.scdn.co/spotify-player.js';
       document.body.appendChild(script);
     }



}
