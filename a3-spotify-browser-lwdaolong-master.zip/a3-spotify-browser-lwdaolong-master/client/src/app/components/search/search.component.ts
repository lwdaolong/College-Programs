import { Component, OnInit } from '@angular/core';
import { SpotifyService } from '../../services/spotify.service';
import { ArtistData } from '../../data/artist-data';
import { AlbumData } from '../../data/album-data';
import { TrackData } from '../../data/track-data';
import { ResourceData } from '../../data/resource-data';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css'],
  providers: [ SpotifyService ]
})
export class SearchComponent implements OnInit {
  searchString:string;
  searchCategory:string = 'artist';
  searchCategories:string[] = ['artist', 'album', 'track'];
  resources:ResourceData[];

  constructor(private spotifyService:SpotifyService) { }

  ngOnInit() {
  }

  search(category:string, resource:string) {
    this.resources = []; //was glitching out without this line? HTML would read previous promise's resources and error out trying to read json that didnt exist
                        //too lazy to research, but find some way to wait for promise to return before updating html
    //console.log("Searching on " + category + resource);
    //TODO: call search function in spotifyService and parse response
    this.spotifyService.searchFor(category,resource).then((data)=>{
        this.resources = data;
        console.log(this.resources[0]);
    });
  }

}
