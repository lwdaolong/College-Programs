import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ArtistData } from '../data/artist-data';
import { AlbumData } from '../data/album-data';
import { TrackData } from '../data/track-data';
import { ResourceData } from '../data/resource-data';
import { ProfileData } from '../data/profile-data';
import { TrackFeature } from '../data/track-feature';

@Injectable({
  providedIn: 'root'
})
export class SpotifyService {
	expressBaseUrl:string = 'http://localhost:8888';

  constructor(private http:HttpClient) { }

  private sendRequestToExpress(endpoint:string):Promise<any> {
    //TODO: use the injected http Service to make a get request to the Express endpoint and return the response.
    //the http service works similarly to fetch(). It may be useful to call .toPromise() on any responses.
    let request_url:string = this.expressBaseUrl + endpoint;
    //update the return to instead return a Promise with the data from the Express server
    //Note: toPromise() is a deprecated function that will be removed in the future.
    //It's possible to do the assignment using lastValueFrom, but we recommend using toPromise() for now as we haven't
    //yet talked about Observables. https://indepth.dev/posts/1287/rxjs-heads-up-topromise-is-being-deprecated
    let request_promise = this.http.get(request_url).toPromise();
    return Promise.resolve(request_promise); //I don't really know why we need Promise.resolve() because it already is a promise but maybe ask in class
  }

  aboutMe():Promise<ProfileData> {
    //This line is sending a request to express, which returns a promise with some data. We're then parsing the data 
    return this.sendRequestToExpress('/me').then((data) => {
      return new ProfileData(data);
    });
  }

  searchFor(category:string, resource:string):Promise<ResourceData[]> {
    //TODO: identify the search endpoint in the express webserver (routes/index.js) and send the request to express.
    //Make sure you're encoding the resource with encodeURIComponent().
    //Depending on the category (artist, track, album), return an array of that type of data.
    //JavaScript's "map" function might be useful for this, but there are other ways of building the array.

    var searchResults = [];
    return this.sendRequestToExpress('/search/' + category + '/' + encodeURIComponent(resource)).then((data) => {
        if(category == "artist"){
            data['artists']['items'].forEach(artist =>{
                searchResults.push(new ArtistData(artist));
            });
        }else if(category == "album"){
            data['albums']['items'].forEach(album =>{
            searchResults.push(new AlbumData(album));
            });
        }else if(category == "track"){
            data['tracks']['items'].forEach(track =>{
            searchResults.push(new TrackData(track));
            });
        }

        return searchResults;
    });
  }

  getArtist(artistId:string):Promise<ArtistData> {
    //TODO: use the artist endpoint to make a request to express.
    //Again, you may need to encode the artistId.
    return this.sendRequestToExpress('/artist/' + encodeURIComponent(artistId)).then((data)=>{
      return new ArtistData(data)
    });
  }

  getRelatedArtists(artistId:string):Promise<ArtistData[]> {
    //TODO: use the related artist endpoint to make a request to express and return an array of artist data.
    var relatedartists = [];
    return this.sendRequestToExpress('/artist-related-artists/' + encodeURIComponent(artistId)).then((data)=>{
      data['artists'].forEach(element => {
        relatedartists.push(new ArtistData(element))
      });
      return relatedartists;
    });
  }

  getTopTracksForArtist(artistId:string):Promise<TrackData[]> {
    //TODO: use the top tracks endpoint to make a request to express.
    var toptracks = [];
    return this.sendRequestToExpress('/artist-top-tracks/' + encodeURIComponent(artistId)).then((data)=>{
      data['tracks'].forEach(element => {
        toptracks.push(new TrackData(element))
      });
      return toptracks;
    });
  }

  getAlbumsForArtist(artistId:string):Promise<AlbumData[]> {
    //TODO: use the albums for an artist endpoint to make a request to express.
    var artistalbums = [];
    return this.sendRequestToExpress('/artist-albums/' + encodeURIComponent(artistId)).then((data)=>{
      data['items'].forEach(element => {
        artistalbums.push(new AlbumData(element))
      });
      return artistalbums;
    });
  }

  getAlbum(albumId:string):Promise<AlbumData> {
    //TODO: use the album endpoint to make a request to express.
    return this.sendRequestToExpress('/album/' + encodeURIComponent(albumId)).then((data)=>{
      return new AlbumData(data)
    });
  }

  getTracksForAlbum(albumId:string):Promise<TrackData[]> {
    //TODO: use the tracks for album endpoint to make a request to express.
    var toptracks = [];
    return this.sendRequestToExpress('/album-tracks/' + encodeURIComponent(albumId)).then((data)=>{
      data['items'].forEach(element => {
        toptracks.push(new TrackData(element))
      });
      return toptracks;
    });
  }

  getTrack(trackId:string):Promise<TrackData> {
    //TODO: use the track endpoint to make a request to express.
    return this.sendRequestToExpress('/track/' + encodeURIComponent(trackId)).then((data)=>{
      return new TrackData(data)
    });
  }

  getAudioFeaturesForTrack(trackId:string):Promise<TrackFeature[]> {
    //TODO: use the audio features for track endpoint to make a request to express.
    var features = []
    return this.sendRequestToExpress('/track-audio-features/' + encodeURIComponent(trackId)).then((data)=>{
      TrackFeature.FeatureTypes.forEach(featuretype => { //TrackFeature has static string of all features we can iterate through instead of hardcoding
        features.push(new TrackFeature(featuretype, data[featuretype])) //instantiate array of TrackFeature objects
      });
      return features;
    });
  }
}
