--Readme document for *Logan Wang*, *loganw1@uci.edu*, *51603232*--

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

15/15
- 2/2 Communicating with the webserver
- 2/2 Populating information about the user
- 3/3 Populating the search component
- 3/3 Artist page
- 2.5/2.5 Album page
- 2.5/2.5 Track page


2. How long, in hours, did it take you to complete this assignment?
	16  hours


3. What online resources did you consult when completing this assignment? (list specific URLs)
	https://angular.io/api/common/NgFor
	https://www.youtube.com/watch?v=DHvZLI7Db8E&t=202s&ab_channel=WebDevSimplified


4. What classmates or other individuals did you consult as part of this assignment? What did you discuss?
	None


5. Did you add a bonus feature to your submission? If so, what is it and how should we see it?
	None


6. Is there anything special we need to know in order to run your code?
	None
