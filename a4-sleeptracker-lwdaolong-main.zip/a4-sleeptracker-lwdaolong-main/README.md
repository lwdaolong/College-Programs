--Readme document for *Logan Wang*, *loganw1@uci.edu*, *51603232*--

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

20/20
- 2/2 The ability to log overnight sleep
- 2/2 The ability to log sleepiness during the day
- 2/2 The ability to view these two categories of logged data
- 4/4 Either using a native device resource or backing up logged data
- 4/4 Following good principles of mobile design
- 4/4 Creating a compelling app
- 2/2 A readme and demo video which explains how these features were implemented and their design rationale

2. How long, in hours, did it take you to complete this assignment?
	23 hours


3. What online resources did you consult when completing this assignment? (list specific URLs)

	https://ionicframework.com/docs/api/card
	https://capacitorjs.com/docs/apis/preferences
	https://www.youtube.com/watch?v=ZHwene3NtxY&ab_channel=BracketsAcademy
	https://stackoverflow.com/questions/72953082/how-to-show-dynamic-component-in-angular-ionic-modal
	https://stackoverflow.com/questions/6195729/most-efficient-way-to-prepend-a-value-to-an-array
	https://www.youtube.com/watch?v=_BnCRIZ1nDk&ab_channel=SimonGrimm


4. What classmates or other individuals did you consult as part of this assignment? What did you discuss?

	N/A, worked alone

5. Is there anything special we need to know in order to run your code?
	N/A


--Aim for no more than two sentences for each of the following questions.--


6. Did you design your app with a particular type of user in mind? If so, whom?

	I designed the app for users who wanted a simple no frills app, where it takes less than a second to log important information.
	This is because most people want to stay off their phone when going to sleep, so it takes only 2 taps to log tiredness, and 2 taps to log sleeps.

7. Did you design your app specifically for iOS or Android, or both?

	My app is designed for both IOS and Android and does not utilize native features of either OS.

8. How can a person log overnight sleep in your app? Why did you choose to support logging overnight sleep in this way?
	On the home page, a user can log sleeps by simply pressing the button "Start Sleeping!" and later press the new button "Just Woke Up!" upon waking.
	I designed it this way so that users can log their sleep in real time and not have to fuss with inputing a duration and multiple dates, however
	editting logged data is supported if a user so desires. The app also supports error prevention to not allow any action or concurrent overnight sleeps.


9. How can a person log sleepiness during the day in your app? Why did you choose to support logging sleepiness in this way?
	On the second tab of the app, a user can simply choose a number from a number line and press "I'm Tired." to log tiredness at the current time.
	This was designed to allow for quickly jotting down how tired you are at a given moment to releive stress on the user from giving a reason they are so tired.
	The number line automatically shows the Stanford Sleepiness Scale's description for each tier of sleepiness, and sleepiness cannot be logged while an
	"overnight sleep" is in progress.


10. How can a person view the data they logged in your app? Why did you choose to support viewing logged data in this way?
	Simply scrolling down on the respective page (Overnight or Sleepiness) will show all logged data sorted from most recent to most past data.
	This was designed this way to show that the user is logging data in real time, as they can see the list update after logging.
	Each datalog can also be clicked to view more details, edit that instance of data, or even delete that data from the log.


11. Which feature choose--using a native device resource, backing up logged data, or both?
	I chose to back up logged data on the device. This was implemented with Capacitors Preferences plugin.


12. If you used a native device resource, what feature did you add? How does this feature change the app's experience for a user?
	N/A.

13. If you backed up logged data, where does it back up to?
	The data is backed up on to the device via Capacitors Preferences plugin. According to documentation, the data is stored on 
	UserDefaults on IOS and SharedPreferences on Android, and will be cleared upon deletion of the application.
	Each piece of logged data is stored as a JSON here.

14. How does your app implement or follow principles of good mobile design?
	The app overall was designed to be used with as little inputs as possible while also providing detailed information and
	preventing user error.

	Only 3 tabs are included, each of which have descriptive, and big easy to use buttons that are unique to their tab.

	A useful initial view is provided by a home page that only has one button, allowing the user to log their sleep and view those logs.
		This allows users to analyze most of their data at a glance, but they can also click on items in their log to see more detailed views,
		edit, and delete their data. All logs are also sorted from mose recently logged items to older items to help users see their most recent data form a glance.
		The sorting of logs is sorted on refresh of the application.

	The “uh-oh” button is provided in the "settings" tab, allowing the user to clear all data and reset the app if a problem has occurred
	or if they just want to start over.

	Error prevention is implemented in multiple ways. First off, most buttons are disabled when an overnight sleep is started.
	This prevents concurrent overnight sleeps. Additionally, when editting ovnight sleeps, certain dates and times are restricted
	so that you cannot end up with negative sleep. When logging sleepiness, only a range is shown so that valid inputs can only be chosen.
	Whenever a significant change would be made, an alert asks for permission in order to prevent erronous mistakes and reinforce the action by users.
	

	Dark mode platform conventions, widget conventions, and icon conventions were also followed for both platforms. 