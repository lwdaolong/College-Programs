import { SleepData } from './sleep-data';

export class OvernightSleepData extends SleepData {
	public sleepStart:Date;
	public sleepEnd:Date;


	constructor(sleepStart:Date, sleepEnd:Date) {
		super();
		this.sleepStart = sleepStart;
		this.sleepEnd = sleepEnd;
	}

	edit(sleepStart:Date, sleepEnd:Date){
	    this.sleepStart = sleepStart;
        this.sleepEnd = sleepEnd;
        this.loggedAt = sleepStart;
        //this.loggedAt = new Date(); // right now! Not sure if gonna need this yet?
	}

	//separate constructor for JSON file, used for consistent data
	//constructor(overnight_json) {
    //		super();
    //	}



    duration():number{
        var sleepStart_ms = this.sleepStart.getTime();
        var sleepEnd_ms = this.sleepEnd.getTime();

        // Calculate the difference in milliseconds
        var difference_ms = sleepEnd_ms - sleepStart_ms;
        return (difference_ms / (1000*60*60));
    }

	summaryString():string {
		var sleepStart_ms = this.sleepStart.getTime();
		var sleepEnd_ms = this.sleepEnd.getTime();

		// Calculate the difference in milliseconds
		var difference_ms = sleepEnd_ms - sleepStart_ms;
		    
		// Convert to hours and minutes
		//return Math.floor(difference_ms / (1000*60*60)) + " hours, " + Math.floor(difference_ms / (1000*60) % 60) + " minutes.";
		return (difference_ms / (1000*60*60)).toFixed(2) + " hours, " +this.getConvenientDateString();
	}

	dateString():string {
		return "Night of " + this.sleepStart.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
	}

	toJSON() {
        return JSON.stringify({
                                         type: "overnight",
                                         id: this.id,
                                         loggedAt: this.loggedAt,
                                         sleepStart: this.sleepStart,
                                         sleepEnd: this.sleepEnd
                                     });
    }
}
