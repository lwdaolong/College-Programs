import { generate } from 'shortid';

export class SleepData {
	id:string;
	loggedAt:Date;
	private closedays = ["Today", "Yesterday","2 Days Ago","3 Days Ago","4 Days Ago","5 Days Ago","6 Days Ago","7 Days Ago","One Week Ago"]

	constructor() {
		//Assign a random (unique) ID. This may be useful for comparison (e.g., are two logged entries the same).
		this.id = generate();
		this.loggedAt = new Date();
	}

	summaryString():string {
		return 'Unknown sleep data';
	}

	dateString():string {
		return this.loggedAt.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
	}

	tempString():string{
	    return this.loggedAt.toLocaleString('en-US');
	}


	getConvenientDateString(){
            var date_today = new Date();
            var difference = date_today.getTime() - this.loggedAt.getTime();
            var tot_days = Math.ceil(difference/(1000*3600*24)) -1;
            if(tot_days <7 && tot_days>-1){
                return this.closedays[tot_days];
            }
            return this.loggedAt.toLocaleDateString();

     }


	toJSON() {
        return JSON.stringify({
                                                     type: "default",
                                                     id: this.id,
                                                     loggedAt: this.loggedAt
                                         });
	}
}
