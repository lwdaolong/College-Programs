import { StanfordSleepinessData } from './stanford-sleepiness-data';

describe('StanfordSleepinessData', () => {
  it('should create an instance', () => {
    expect(new StanfordSleepinessData()).toBeTruthy();
  });
});
