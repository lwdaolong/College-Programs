import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePage } from './home.page';

const routes: Routes = [
  {
    path: 'home',
    component: HomePage,
    children: [
    {
        path: 'log-page',
        loadChildren: () => import('../log-page/log-page.module').then( m => m.LogPagePageModule)
      },
      {
        path: 'view-page',
        loadChildren: () => import('../view-page/view-page.module').then( m => m.ViewPagePageModule)
      },
      {
          path: 'settings-page',
          loadChildren: () => import('../settings-page/settings-page.module').then( m => m.SettingsPagePageModule)
        },
    ]
  },
  {
    path: '',
    redirectTo: '/home/log-page',
    pathMatch: 'full'

  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomePageRoutingModule {}
