import { Component, ViewChild } from '@angular/core';
import { SleepService } from '../services/sleep.service';
import { SleepData } from '../data/sleep-data';
import { OvernightSleepData } from '../data/overnight-sleep-data';
import { StanfordSleepinessData } from '../data/stanford-sleepiness-data';

import { Preferences } from '@capacitor/preferences';


import { RangeCustomEvent } from '@ionic/angular';
import { RangeValue } from '@ionic/core';


@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
    //sleep_log_in_progress:boolean;
    //curr_overnight_start_date:SleepData;
    //curr_overnight_end_date:SleepData;

    lastEmittedValue: RangeValue = 1;


	constructor(public sleepService:SleepService) {
        //this.sleep_log_in_progress = false;
        this.sleepService = sleepService;

	}

	ngOnInit() {
		//console.log(this.allSleepData);
        //console.log(SleepService.startsleepobject);
        ///^ for now, set as false, may not be true with persistent data later
	}





	 onIonChange(ev: Event) {
        this.lastEmittedValue = (ev as RangeCustomEvent).detail.value;
      }


    async clearStorage(){
        this.sleepService.clearStorage();
    }

	/* Ionic doesn't allow bindings to static variables, so this getter can be used instead. */
	get allSleepData() {
		return SleepService.AllSleepData;
	}

	public SleepinessDetails(value) {
    		return StanfordSleepinessData.ScaleValues[value];
    }

	get allOvernightData() {
        return SleepService.AllOvernightData;
    }

    get allSleepinessData() {
        return SleepService.AllSleepinessData;
    }

    get curr_overnight_start_date(){
        return SleepService.latest_overnight_start_date;
    }

    get curr_overnight_end_date(){
        return SleepService.latest_overnight_end_date;
    }

    public updateCurrOvernightStartDate() {
        this.sleepService.logStartSleepData(this.curr_overnight_start_date);
        /*
        if(this.sleep_log_in_progress == true){
            console.log("Can't update if current overnight has not finished logging");
            ///error prevention
            ///future, maybe make the justification to prompt the user to throw away the old sleep log and start a new one
        }else{
            //update the start Date object used to log overnight sleeps
            this.curr_overnight_start_date = new SleepData();
            this.sleepService.logStartSleepData(this.curr_overnight_start_date);
            this.sleep_log_in_progress = true;
        }
        */
    }

    public completeOvernightSleepLog() {

        this.sleepService.logOvernightData(new OvernightSleepData(new Date(),new Date()));
        /*
        if(this.sleep_log_in_progress == true){
            this.curr_overnight_end_date = new SleepData();
            this.sleepService.logOvernightData(new OvernightSleepData(this.curr_overnight_start_date.loggedAt,this.curr_overnight_end_date.loggedAt));
            this.sleep_log_in_progress = false;
            this.sleepService.deleteStartSleepData();
            //put a pop up to show the user has really completed the action of logging the sleep
        }else{
            console.log("Can't finish logging if overnight sleep has not been started");
            ///error prevention
            ///Maybe even grey out button if ngIf that attribute is false
        }
        */
    }

    public logTirednessData(tired_int:number) {
            this.sleepService.logSleepinessData(new StanfordSleepinessData(tired_int, new Date()));
            /*
            if(this.sleep_log_in_progress == true){
                console.log("Shouldn't be able to do anything while sleep is in progress");
                ///error prevention
                ///future, maybe make the justification to prompt the user to throw away the old sleep log and start a new one
            }else{
                //update the start Date object used to log overnight sleeps
                this.sleepService.logSleepinessData(new StanfordSleepinessData(tired_int, new Date()));
            }

            */
        }

}

