import { Injectable } from '@angular/core';
import { SleepData } from '../data/sleep-data';
import { OvernightSleepData } from '../data/overnight-sleep-data';
import { StanfordSleepinessData } from '../data/stanford-sleepiness-data';

import { Preferences } from '@capacitor/preferences';

@Injectable({
  providedIn: 'root'
})
export class SleepService {
	private static LoadDefaultData:boolean = true;
	public static AllSleepData:SleepData[] = [];
	public static AllOvernightData:OvernightSleepData[] = [];
	public static AllSleepinessData:StanfordSleepinessData[] = [];

    //used to indicate whether a sleep is in progress or not
	public static startsleepobject:SleepData = null;

	public static latest_overnight_start_date:SleepData = null;
    public static latest_overnight_end_date:SleepData = null;


	constructor() {
		if(SleepService.LoadDefaultData) {
			this.addDefaultData();

		SleepService.LoadDefaultData = false;
		//this.addRandomDataForTesting();

	}
	}

	private addRandomDataForTesting(){
	    this.logOvernightData(new OvernightSleepData(new Date('February 18, 2021 01:03:00'), new Date('February 18, 2021 09:25:00')));
        this.logSleepinessData(new StanfordSleepinessData(4, new Date('February 19, 2021 14:38:00')));
        this.logOvernightData(new OvernightSleepData(new Date('February 20, 2021 23:11:00'), new Date('February 21, 2021 08:03:00')));
        this.logSleepinessData(new StanfordSleepinessData(7, new Date('February 10, 1 14:38:00')));
        this.logSleepinessData(new StanfordSleepinessData(6, new Date('February 9, 2 14:38:00')));
        this.logSleepinessData(new StanfordSleepinessData(5, new Date('February 8, 3 14:38:00')));
        this.logSleepinessData(new StanfordSleepinessData(4, new Date('February 7, 4 14:38:00')));
        this.logSleepinessData(new StanfordSleepinessData(3, new Date('February 6, 5 14:38:00')));
        this.logSleepinessData(new StanfordSleepinessData(2, new Date('February 5, 6 14:38:00')));
        this.logSleepinessData(new StanfordSleepinessData(1, new Date('February 4, 7 14:38:00')));
	}

	private async addDefaultData() {
	    //Preferences.clear();

        var pre_existing_keys_interim = await this.getKeys();
        var pre_existing_keys = pre_existing_keys_interim.keys;
        //console.log(pre_existing_keys);

        pre_existing_keys.forEach(this.testfunction);
        //pre_existing_keys.forEach(sleepJSONKey => this.constructSleepDataFromJSON(Preferences.get({ key: sleepJSONKey}),true));

        await SleepService.AllSleepData.sort(this.sleepcompare);
        await SleepService.AllOvernightData.sort(this.sleepcompare);
        await SleepService.AllSleepinessData.sort(this.sleepcompare);
	}

    //used to sort in reverse, so the most recent Date will be at the beginnig of the array, oldest Date at end
    private sleepcompare(a,b){
        if (a.loggedAt.getTime() < b.loggedAt.getTime()){
            return 1;
        }
        if(a.loggedAt.getTime() > b.loggedAt.getTime()){
            return -1;
        }
        return 0;
    }
    //something is not working where it is not recognizing my other functions, so just copy pasted the functions
    //what it SHOULD look like and IS doing is:
    /*
        async testfunction(item){
                var temp = await Preferences.get({ key: item});
                var sleepJSON = JSON.parse(temp.value);
                constructSleepDataFromJSON(sleepJSON, true};
    */
	async testfunction(item){
        var temp = await Preferences.get({ key: item});
        var sleepJSON = JSON.parse(temp.value);
        //console.log(item);
        //console.log('SHOULD BE A JSON', sleepJSON);
        var also_log = true;
        var tempSleepJSON = sleepJSON;
        	    //var tempSleepJSON = data_chunk.value;

        	    if(tempSleepJSON.type == "overnight"){
                    var tempOvernight = new OvernightSleepData(new Date(tempSleepJSON.sleepStart), new Date(tempSleepJSON.sleepEnd));
                    tempOvernight.id = tempSleepJSON.id;
                    tempOvernight.loggedAt = new Date(tempSleepJSON.loggedAt);
                    if(also_log == true){
                        SleepService.AllSleepData.unshift(tempOvernight);
                        		SleepService.AllOvernightData.unshift(tempOvernight);
                        		if(SleepService.LoadDefaultData == false){
                        		    //also push the data into Preferences to ensure persistent data
                                     var temp_value_json = JSON.parse(tempOvernight.toJSON());
                                     	    var temp_string_json = tempOvernight.toJSON();
                                     	    //console.log(temp_string_json);

                                             await Preferences.set({
                                                 key: temp_value_json.id,
                                                 value: temp_string_json
                                             });

                        		}
                    }

                    return tempOvernight;
        	    }else if (tempSleepJSON.type == "sleepiness"){
                    var tempSleepiness = new StanfordSleepinessData(tempSleepJSON.loggedValue);
                    tempSleepiness.id = tempSleepJSON.id;
                    tempSleepiness.loggedAt = new Date(tempSleepJSON.loggedAt);
                    if(also_log == true){
                        SleepService.AllSleepData.unshift(tempSleepiness);
                        		SleepService.AllSleepinessData.unshift(tempSleepiness);
                        		if(SleepService.LoadDefaultData == false){
                                    //also push the data into Preferences to ensure persistent data
                                    var temp_value_json = JSON.parse(tempSleepiness.toJSON());
                                                                         	    var temp_string_json = tempSleepiness.toJSON();
                                                                         	    //console.log(temp_string_json);

                                                                                 await Preferences.set({
                                                                                     key: temp_value_json.id,
                                                                                     value: temp_string_json
                                                                                 });
                                }
                    }

                    return tempSleepiness;
        	    }else if(tempSleepJSON.type == "default"){
        	        var tempSleep = new SleepData();
        	        tempSleep.id = tempSleepJSON.id;
                    tempSleep.loggedAt = new Date(tempSleepJSON.loggedAt);
        	        SleepService.startsleepobject = tempSleep;
        	        SleepService.latest_overnight_start_date = SleepService.startsleepobject;
        	    }else{
        	        console.log("ERROR, invalid type attribute or no type attribute")
        	    }
    }

	//super jank and not good practice, but the fastest I could get this working
	public constructSleepDataFromJSON(data_chunk, also_log = false){
	    //console.log('DATACHUNK',data_chunk);
	    var tempSleepJSON = data_chunk;
	    //var tempSleepJSON = data_chunk.value;

	    if(tempSleepJSON.type == "overnight"){
            var tempOvernight = new OvernightSleepData(new Date(tempSleepJSON.sleepStart), new Date(tempSleepJSON.sleepEnd));
            tempOvernight.id = tempSleepJSON.id;
            tempOvernight.loggedAt = new Date(tempSleepJSON.loggedAt);
            if(also_log == true){
                this.logOvernightData(tempOvernight);
            }

            return tempOvernight;
	    }else if (tempSleepJSON.type == "sleepiness"){
            var tempSleepiness = new StanfordSleepinessData(tempSleepJSON.loggedValue);
            tempSleepiness.id = tempSleepJSON.id;
            tempSleepiness.loggedAt = new Date(tempSleepJSON.loggedAt);
            if(also_log == true){
                this.logSleepinessData(tempSleepiness);
            }

            return tempSleepiness;
	    }else{
	        console.log("ERROR, invalid type attribute or no type attribute")
	    }
	}

	public async clearStorage(){
	    //print warning, this will delete your current in progress sleep as well
        await Preferences.clear();
        SleepService.AllSleepData = [];
        SleepService.AllOvernightData = [];
        SleepService.AllSleepinessData = [];
    }

    async removeItem(sleepData){
        await Preferences.remove({key: sleepData.id});

        var allsleepdataindex = SleepService.AllSleepData.indexOf(sleepData);
        var allovernightindex = SleepService.AllOvernightData.indexOf(sleepData);
        var allsleepinessindex = SleepService.AllSleepinessData.indexOf(sleepData);

        if(allsleepdataindex >-1){
            SleepService.AllSleepData.splice(allsleepdataindex,1);
        }
        if(allovernightindex >-1){
            SleepService.AllOvernightData.splice(allovernightindex,1);
        }
        if(allsleepinessindex >-1){
            SleepService.AllSleepinessData.splice(allsleepinessindex,1);
        }
    }

    async editOvernight(sleepData, new_start_date = new Date('February 18, 2021 01:03:00'), new_end_date = new Date('February 18, 2021 09:25:00')){
        sleepData.edit(new_start_date, new_end_date);
        this.pushSleepDataToCapacitor(sleepData);
    }


    async editSleepiness(sleepData:StanfordSleepinessData, sleepiness_level, update_date){
       sleepData.edit(sleepiness_level,update_date);
       this.pushSleepDataToCapacitor(sleepData);
    }

    async getKeys(){
        var keys = await Preferences.keys();
        return keys;
    }


	async pushSleepDataToCapacitor(sleepData:SleepData){
	    //TODO check if uses parent methods
	    var temp_value_json = JSON.parse(sleepData.toJSON());
	    var temp_string_json = sleepData.toJSON();
	    //console.log(temp_string_json);

        await Preferences.set({
            key: temp_value_json.id,
            value: temp_string_json
        });

	}


	public logOvernightData(sleepData:OvernightSleepData) {
	    //assumes LoadDefaultData is true at this point, so will read data from Preferences and not add back in, like an ordinary call to log would
        if(SleepService.LoadDefaultData == true){
            SleepService.AllSleepData.unshift(sleepData);
            SleepService.AllOvernightData.unshift(sleepData);
        }

		if(SleepService.LoadDefaultData == false && SleepService.startsleepobject != null){
		    //also push the data into Preferences to ensure persistent data
		    SleepService.latest_overnight_end_date = new SleepData();
		    var overnight_sleep_new = new OvernightSleepData(SleepService.startsleepobject.loggedAt,SleepService.latest_overnight_end_date.loggedAt);

            SleepService.AllSleepData.unshift(overnight_sleep_new);
            SleepService.AllOvernightData.unshift(overnight_sleep_new);
             this.pushSleepDataToCapacitor(overnight_sleep_new);
             this.deleteStartSleepData();
		}else{

            console.log("Can't finish logging if overnight sleep has not been started");
            ///error prevention
            ///Maybe even grey out button if ngIf that attribute is false

		}
	}

	public logSleepinessData(sleepData:StanfordSleepinessData) {
	    //assumes LoadDefaultData is true at this point, so will read data from Preferences and not add back in, like an ordinary call to log would
	    if(SleepService.LoadDefaultData == true){
	        SleepService.AllSleepData.unshift(sleepData);
            SleepService.AllSleepinessData.unshift(sleepData);
	    }

		if(SleepService.LoadDefaultData == false && SleepService.startsleepobject == null){
            //also push the data into Preferences to ensure persistent data
            SleepService.AllSleepData.unshift(sleepData);
            SleepService.AllSleepinessData.unshift(sleepData);
            this.pushSleepDataToCapacitor(sleepData);
        }else{
            console.log("Shouldn't be able to do anything while sleep is in progress");
            ///error prevention
            ///future, maybe make the justification to prompt the user to throw away the old sleep log and start a new one
        }
	}

    public logStartSleepData(sleepData:SleepData){
        if(SleepService.LoadDefaultData == false && SleepService.startsleepobject == null){
            //also push the data into Preferences to ensure persistent data
            SleepService.startsleepobject = new SleepData();
            this.pushSleepDataToCapacitor(SleepService.startsleepobject);
            SleepService.latest_overnight_start_date = SleepService.startsleepobject;
        }else{
            console.log("Can't update if current overnight has not finished logging");
        }
    }

    //should only be called in logSleepinessData()
    //meant to delete existing sleepData that is used in the pair of sleepData's used to instantaite a OvernightSleepData
    //this allows user to "start sleeping", then close the app or turn off their phone and the initial sleepData object
    //will persist
    public async deleteStartSleepData(){
        await Preferences.remove({key: SleepService.startsleepobject.id});
        SleepService.startsleepobject = null;
        SleepService.latest_overnight_start_date = null;
    }

}
