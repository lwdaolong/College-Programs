import { Component, OnInit, ViewChild  } from '@angular/core';
import { SleepService } from '../services/sleep.service';
import { SleepData } from '../data/sleep-data';
import { OvernightSleepData } from '../data/overnight-sleep-data';
import { StanfordSleepinessData } from '../data/stanford-sleepiness-data';
import { AlertController } from '@ionic/angular';

import { ActionSheetController } from '@ionic/angular';

import { Preferences } from '@capacitor/preferences';

import {DatetimeCustomEvent } from '@ionic/angular';
import { RangeCustomEvent } from '@ionic/angular';
import { RangeValue } from '@ionic/core';
import { PickerController } from '@ionic/angular';

@Component({
  selector: 'app-view-page',
  templateUrl: './view-page.page.html',
  styleUrls: ['./view-page.page.scss'],
})
export class ViewPagePage implements OnInit {
//sleep_log_in_progress:boolean;
      //curr_overnight_start_date:SleepData;
      //curr_overnight_end_date:SleepData;
      result: string;
      recursivecheck = null;

      lastEmittedValue: RangeValue = 1;

      isModalOpen = false;
      currently_selected_sleepdata= null;


  	constructor(public sleepService:SleepService,private actionSheetCtrl: ActionSheetController,private pickerCtrl: PickerController, private alertController: AlertController) {
          //this.sleep_log_in_progress = false;
          this.sleepService = sleepService;

  	}

  	ngOnInit() {
  		//console.log(this.allSleepData);
          //console.log(SleepService.startsleepobject);
          ///^ for now, set as false, may not be true with persistent data later
  	}

  	async presentAlert() {
            const alert = await this.alertController.create({
              header: 'Caution',
              subHeader: 'Are you sure you want to delete?',
              message: 'There is no way to recover this data once deleted',
              buttons: [
                      {
                        text: 'Cancel',
                        role: 'cancel',
                        handler: () => {
                          //this.handlerMessage = 'Alert canceled';
                        },
                      },
                      {
                        text: 'OK',
                        role: 'confirm',
                        handler: () => {
                          //this.handlerMessage = 'Alert confirmed';
                          this.deleteSleepinessData();

                        },
                      },
                    ],
                  });

            await alert.present();
          }


     async openPicker() {
        const picker = await this.pickerCtrl.create({
              columns: [
                {
                  name: 'languages',
                  options: [
                    {
                      text: '1: Feeling active',
                      value: 1,
                    },
                    {
                      text: '2: Functioning at high levels',
                      value: 2,
                    },
                    {
                      text: '3: Awake, but relaxed',
                      value: 3,
                    },
                    {
                      text: '4: Somewhat foggy',
                      value: 4,
                    },
                    {
                      text: '5: Foggy',
                      value: 5,
                    },
                    {
                      text: '6: Sleepy, woozy',
                      value: 6,
                    },
                    {
                      text: '7: Sleep onset soon',
                      value: 7,
                    },

                  ],
                },
              ],
              buttons: [
                {
                  text: 'Cancel',
                  role: 'cancel',
                },
                {
                  text: 'Confirm',
                  handler: (value) => {
                    //console.log(this.currently_selected_sleepdata.loggedValue);
                    //console.log(value.languages.value);
                    this.sleepService.editSleepiness(this.currently_selected_sleepdata,value.languages.value,this.currently_selected_sleepdata.loggedAt);
                    //console.log(this.currently_selected_sleepdata);
                    //window.alert(`You selected: ${value.languages.value}`);
                  },
                },
              ],
            });

            await picker.present();
     }

    getTimeZoneISO(){
        var tzoffset = (new Date()).getTimezoneOffset() * 60000; //offset in milliseconds
        var localISOTime = (new Date(this.currently_selected_sleepdata.loggedAt.getTime() - tzoffset)).toISOString().slice(0, -1);

        return localISOTime;
    }

     deleteSleepinessData(){
        this.sleepService.removeItem(this.currently_selected_sleepdata);
        this.setOpen(false);
        this.currently_selected_sleepdata = null;

     }



      setOpen(isOpen: boolean, sleepData = this.currently_selected_sleepdata) {
        this.isModalOpen = isOpen;
        this.currently_selected_sleepdata = sleepData;
      }

    async presentActionSheet(sleepData) {
        const actionSheet = await this.actionSheetCtrl.create({
          header: 'Edit',
          //subHeader: sleepData.summaryString2(),
          buttons: [
          {
            text: sleepData.summaryString2(),
            data: {
              action: 'edit_sleepiness_value',
            },
          },
          {
              text: sleepData.loggedAt.toLocaleString(),
              data: {
                action: 'edit_sleepiness_date',
              },
            },
            {
              text: 'Delete',
              role: 'destructive',
              data: {
                action: 'delete',
              },
            },
            {
              text: 'Cancel',
              role: 'cancel',
              data: {
                action: 'cancel',
              },
            },
          ],
        });

        await actionSheet.present();

        const result = await actionSheet.onDidDismiss();
        this.result = JSON.stringify(result, null, 2);
      }



  	 onIonChange(ev: Event) {
          this.lastEmittedValue = (ev as RangeCustomEvent).detail.value;
        }

     datechanged(ev: Event) {
     if(this.recursivecheck == false){
       	        return;
       	    }
       	   this.recursivecheck = false;
       var temptime = (ev as DatetimeCustomEvent).detail.value;
       //console.log( temptime);
       //var b = (temptime as string).split(/\D+/);
       var b = Date.parse((temptime as string));
       var d = new Date(b);
       //console.log(b);
       //console.log(d);
       //var d =  new Date(Date.UTC(b[0], --b[1], b[2], b[3], b[4], b[5], b[6]));
       this.sleepService.editSleepiness(this.currently_selected_sleepdata,this.currently_selected_sleepdata.loggedValue,d);

       //incredibly stupid, but this is a bug with ionic that is not fixed in which ionchange will call infinitely on a big delta of dates
              setTimeout(() => {
                console.log("Delayed for 1 second.");
                this.recursivecheck = true;
              }, 1000)
     }


      async clearStorage(){
          this.sleepService.clearStorage();
      }

  	/* Ionic doesn't allow bindings to static variables, so this getter can be used instead. */
  	get allSleepData() {
  		return SleepService.AllSleepData;
  	}

  	public SleepinessDetails(value) {
      		return StanfordSleepinessData.ScaleValues[value];
      }

  	get allOvernightData() {
          return SleepService.AllOvernightData;
      }

      get allSleepinessData() {
          return SleepService.AllSleepinessData;
      }

      get curr_overnight_start_date(){
          return SleepService.latest_overnight_start_date;
      }

      get curr_overnight_end_date(){
          return SleepService.latest_overnight_end_date;
      }

      public updateCurrOvernightStartDate() {
          this.sleepService.logStartSleepData(this.curr_overnight_start_date);
          /*
          if(this.sleep_log_in_progress == true){
              console.log("Can't update if current overnight has not finished logging");
              ///error prevention
              ///future, maybe make the justification to prompt the user to throw away the old sleep log and start a new one
          }else{
              //update the start Date object used to log overnight sleeps
              this.curr_overnight_start_date = new SleepData();
              this.sleepService.logStartSleepData(this.curr_overnight_start_date);
              this.sleep_log_in_progress = true;
          }
          */
      }

      public completeOvernightSleepLog() {

          this.sleepService.logOvernightData(new OvernightSleepData(new Date(),new Date()));
          /*
          if(this.sleep_log_in_progress == true){
              this.curr_overnight_end_date = new SleepData();
              this.sleepService.logOvernightData(new OvernightSleepData(this.curr_overnight_start_date.loggedAt,this.curr_overnight_end_date.loggedAt));
              this.sleep_log_in_progress = false;
              this.sleepService.deleteStartSleepData();
              //put a pop up to show the user has really completed the action of logging the sleep
          }else{
              console.log("Can't finish logging if overnight sleep has not been started");
              ///error prevention
              ///Maybe even grey out button if ngIf that attribute is false
          }
          */
      }

      public logTirednessData(tired_int:number) {
              this.sleepService.logSleepinessData(new StanfordSleepinessData(tired_int, new Date()));
              /*
              if(this.sleep_log_in_progress == true){
                  console.log("Shouldn't be able to do anything while sleep is in progress");
                  ///error prevention
                  ///future, maybe make the justification to prompt the user to throw away the old sleep log and start a new one
              }else{
                  //update the start Date object used to log overnight sleeps
                  this.sleepService.logSleepinessData(new StanfordSleepinessData(tired_int, new Date()));
              }

              */
          }

}
