package com.myservlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet(urlPatterns = "/add_review")
public class AddReviewServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pid = req.getParameter("pid");
        String rating = req.getParameter("rate");
        PrintWriter writer = resp.getWriter();
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + "retroware", "root", "root1234");
            Statement stmt = con.createStatement();
            String sql = String.format("INSERT INTO reviews (review_score,pid)\n" +
                    "VALUES(\"%s\", \"%s\")", rating, pid);
            int rs = stmt.executeUpdate(sql);

            resp.setContentType("text/html");
            PrintWriter out = resp.getWriter();
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Review Submitted!');");
            out.println("</script>");

        }
        catch (ClassNotFoundException e){
            writer.println("<html> <body>");
            writer.println("<h3> Could not load driver </h3>");
            writer.println("</body> </html> ");
        }
        catch (SQLException e) {
            e.printStackTrace();
            writer.println("<html> <body>");
            writer.println("Name: "+ pid + " Email: " + rating);
            writer.println("<h3> There was an error inserting the data </h3>");
            writer.println("</body> </html> ");
        }
        
        
        
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    }
}
