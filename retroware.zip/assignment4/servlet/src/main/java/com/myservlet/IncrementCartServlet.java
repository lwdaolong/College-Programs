package com.myservlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

@WebServlet(urlPatterns = "/increment_cart")
public class IncrementCartServlet extends HttpServlet {
    @Override
    public void init() throws ServletException {
        super.init();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pid = req.getParameter("pid");
        String name = req.getParameter("name");
        HttpSession session = req.getSession(true);

        String product_cart_count = (String) session.getAttribute(pid);
        if (product_cart_count == null) {
            session.setAttribute(pid, "1");

        } else {
            session.setAttribute(pid, String.valueOf(Integer.parseInt(product_cart_count) + 1));
        }

        //debug
        Enumeration<String> attributes = req.getSession().getAttributeNames();
        while (attributes.hasMoreElements()) {
            String attribute = (String) attributes.nextElement();
            System.out.println(attribute+" : "+req.getSession().getAttribute(attribute));
        }
    }


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pid = req.getParameter("pid");
        HttpSession session = req.getSession(true);

        String product_cart_count = (String) session.getAttribute(pid);
        if (product_cart_count == null) {
            session.setAttribute(pid, "1");

        } else {
            session.setAttribute(pid, String.valueOf(Integer.parseInt(product_cart_count) + 1));
        }

        resp.sendRedirect(req.getContextPath()+"/checkout/checkout.html");
        //debug

    }
}
