package com.myservlet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.Enumeration;

@WebServlet(urlPatterns = "/order")
public class OrderServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(true);
        int neworderid=0;

        String fname = req.getParameter("fname");
        String lname = req.getParameter("lname");
        String phone = req.getParameter("phone");
        String address = req.getParameter("address");
        String country = req.getParameter("country");
        String zipcode = req.getParameter("zipcode");
        String city = req.getParameter("city");
        String state = req.getParameter("state");
        String shipping = req.getParameter("shipping");
        String cc = req.getParameter("cc");
        String exp = req.getParameter("exp");
        String cvc = req.getParameter("cvc");
        String email = req.getParameter("email");
        String total = req.getParameter("total");



        PrintWriter writer = resp.getWriter();
        /*
        System.out.println(fname);
        System.out.println(lname);
        System.out.println(phone);
        System.out.println(address);
        System.out.println(country);
        System.out.println(zipcode);
        System.out.println(city);
        System.out.println(state);
        System.out.println(shipping);
        System.out.println(cc);
        System.out.println(exp);
        System.out.println(cvc);
        System.out.println(email);
        System.out.println(total);

         */


        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + "retroware", "root", "root1234");
            Statement stmt = con.createStatement();
            String sql = String.format("SELECT orderid FROM retroware.receipts\n" +
                    "ORDER BY orderid DESC\n" +
                    "LIMIT 1;");
            ResultSet rs = stmt.executeQuery(sql);

            //gets the last orderid and increments to prepare insert into database
            while(rs.next()){
                neworderid = rs.getInt("orderid") +1;

            }

            //insert main receipt(no individual products)
            stmt = con.createStatement();
            sql = String.format("INSERT INTO retroware.receipts (orderid,fname,lname,phone,address,country,zip,city,state,method,credit,expiration,cvc,email,total)\n" +
                    "VALUES(%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',%f)",neworderid,fname,lname,phone,address,country,zipcode,city,state,shipping,cc,exp,cvc,email,Float.valueOf(total));
            stmt.executeUpdate(sql);

            Enumeration<String> attributes = req.getSession().getAttributeNames();
            while (attributes.hasMoreElements()) {
                String attribute = (String) attributes.nextElement();
                String quant = String.valueOf(req.getSession().getAttribute(attribute));

                stmt = con.createStatement();
                sql = String.format("INSERT INTO retroware.orders(pid,quant,orderid)\n" +
                        "VALUES(%d,%d,%d)",Integer.valueOf(attribute),Integer.valueOf(quant),neworderid);
                stmt.executeUpdate(sql);


                session.removeAttribute(attribute);
            }




        }
        catch (ClassNotFoundException e){
            writer.println("<html> <body>");
            writer.println("<h3> Could not load driver </h3>");
            writer.println("</body> </html> ");
        }
        catch (SQLException e) {
            e.printStackTrace();
            writer.println("<html> <body>");
            writer.println("<h3> There was an error inserting the data </h3>");
            writer.println("</body> </html> ");
        }


        RequestDispatcher requestDispatcher = req.getRequestDispatcher("/checkout/order_confirmation.jsp?orderid=" +neworderid);
        requestDispatcher.forward(req, resp);
        
        
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    }
}
