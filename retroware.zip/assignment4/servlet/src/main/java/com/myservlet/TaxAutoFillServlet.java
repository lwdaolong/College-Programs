package com.myservlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet("/getTax")
public class TaxAutoFillServlet extends HttpServlet {

    @Override
    public void init() throws ServletException {
        super.init();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String zip = req.getParameter("zip");
        resp.setContentType("text/html;charset=UTF-8");
        PrintWriter writer = resp.getWriter();
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + "retroware", "root", "root1234");
            Statement stmt = con.createStatement();
            String sql = "SELECT * FROM retroware.tax\n" +
                    "WHERE tax.ZipCode ="+zip;
            ResultSet rs = stmt.executeQuery(sql);

            while(rs.next()){
                String tax = rs.getString("CombinedRate");
                String region = rs.getString("TaxRegionName");
                writer.write(String.format("%s,%s", tax,region));

            }

        }
        catch (ClassNotFoundException e){
            writer.println("<html> <body>");
            writer.println("<h3> Could not load driver </h3>");
            writer.println("</body> </html> ");
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

    }
}


/*
@WebServlet("/show")
public class ListServlet extends HttpServlet {

    @Override
    public void init() throws ServletException {
        super.init();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter writer = resp.getWriter();
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + "email", "root", "root1234");
            Statement stmt = con.createStatement();
            String sql = "SELECT name,email FROM email";
            ResultSet rs = stmt.executeQuery(sql);

            writer.println("<html> <body>");
            writer.println("<h3>Email list</h3>");
            while(rs.next()){
                String name = rs.getString("name");
                String email = rs.getString("email");
                writer.println(String.format("<li>Name: %s . Email: %s</li>", name, email));
            }
            writer.println("</body> </html> ");
        }
        catch (ClassNotFoundException e){
            writer.println("<html> <body>");
            writer.println("<h3> Could not load driver </h3>");
            writer.println("</body> </html> ");
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

    }
}


```````````````

@WebServlet("/show")
public class ListServlet extends HttpServlet {

    @Override
    public void init() throws ServletException {
        super.init();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter writer = resp.getWriter();
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + "retroware", "root", "root1234");
            Statement stmt = con.createStatement();
            String sql = "SELECT imgid,path FROM images";
            ResultSet rs = stmt.executeQuery(sql);

            writer.println("<html> <body>");
            writer.println("<h3>Email list</h3>");
            while(rs.next()){
                String name = rs.getString("imgid");
                String email = rs.getString("path");
                writer.println(String.format("<li>Name: %s . Email: %s</li>", name, email));
                writer.println(String.format("<img src='%s' width=\"500\">",email));
            }

            stmt = con.createStatement();
            sql = "SELECT * FROM products";
            rs = stmt.executeQuery(sql);

            writer.println("<h3>Product list</h3>");
            while(rs.next()){
                String pid = rs.getString("pid");
                String brand = rs.getString("brand");
                String name = rs.getString("name");
                String release = rs.getString("release");
                String price = rs.getString("price");
                String desc = rs.getString("desc");
                writer.println(String.format("<li>pid: %s . brand: %s . name: %s . release: %s . price: %s . desc: %s </li>", pid,brand,name,release,price,desc));
            }


            writer.println("</body> </html> ");
        }
        catch (ClassNotFoundException e){
            writer.println("<html> <body>");
            writer.println("<h3> Could not load driver </h3>");
            writer.println("</body> </html> ");
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

    }
}


 */