package com.myservlet;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.Enumeration;

@WebServlet("/show_cart")
public class getCartServlet extends HttpServlet {

    @Override
    public void init() throws ServletException {
        super.init();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(true);


        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        PrintWriter writer = resp.getWriter();

        JSONObject jsonObject = new JSONObject();
        JSONArray array = new JSONArray();

        Enumeration<String> attributes = req.getSession().getAttributeNames();
        while (attributes.hasMoreElements()) {
            String attribute = (String) attributes.nextElement();
            //System.out.println(attribute+" : "+req.getSession().getAttribute(attribute));

            try{

                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + "retroware", "root", "root1234");
                Statement stmt = con.createStatement();
                String sql = "SELECT products.pid,name,price,path\n" +
                        "FROM retroware.products,retroware.images\n" +
                        "WHERE products.pid = images.pid and images.order =0 and products.pid="+attribute;
                ResultSet rs = stmt.executeQuery(sql);

                while(rs.next()){
                    JSONObject record = new JSONObject();

                    //Inserting key-value pairs into the json object
                    record.put("pid", rs.getString("pid"));
                    record.put("name", rs.getString("name"));
                    record.put("price", rs.getString("price"));
                    record.put("path", rs.getString("path"));
                    record.put("quantity",req.getSession().getAttribute(attribute));

                    array.add(record);

                }



            }
            catch (ClassNotFoundException e){
                writer.println("<html> <body>");
                writer.println("<h3> Could not load driver </h3>");
                writer.println("</body> </html> ");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }

        jsonObject.put("product_data", array);
        writer.write(jsonObject.toJSONString());

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
