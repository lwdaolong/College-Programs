
let total =0;

fetch("./../show_cart", {
    method: "GET" // or POST depending your implementation
})
    .then((response) => response.json())
    .then((data) => {
        // data should equal whatever JSON the server is returning
        // you can now populate whatever fields need to be
        //document.getElementById('dynamic_field').innerHTML = data.something;
        //console.log(data);

        //<a href="./../products/product.jsp?pid=${item.pid}">
        const cardContainer = document.querySelector(".card-container");

        data.product_data.forEach((item)=>{
            //console.log(item)
            const card = document.createElement("div");
            card.classList.add("cell");
            //<a href="../products/product_${i}.html">
            card.innerHTML = `
            <a href="./../products/product.jsp?pid=${item.pid}">
            <div class="image-placeholder">
            <img src ="../${item.path}" alt="Product temp image">
            </div>
            <div class="product-name">${item.name}</div>
            <div class="product-price">${item.price}</div>
            <div class="product-quantity"> x ${item.quantity}</div>
            <div class="card-total"> = ${(item.price*item.quantity).toFixed(2)}</div>
            <div>
                <form class = "half" action="./../decrement_cart" method="post">
                  <input type="hidden" name="pid" id ="cartadd" value="${item.pid}" />
                    <input class =" blue strong" type="submit" value="-">    
                </form>
                <form class = "half" action="./../increment_cart" method="post">
                  <input type="hidden" name="pid" id ="cartadd" value="${item.pid}" />
                    <input class =" blue strong" type="submit" value="+">    
                </form>
            </div>
            
            </a>
                `;
            cardContainer.appendChild(card);

            total += (item.price * item.quantity);

        })

        var totprice = document.getElementById("carttotal");
        totprice.innerHTML = total.toFixed(2);

        document.getElementById("taxtotal").innerHTML = total.toFixed(2);

        var totprice2 = document.getElementById("carttotal2");
        totprice2.innerHTML = total.toFixed(2);

        var totprice3 = document.getElementById("hiddentotal");
        totprice3.value = total.toFixed(2);

    });


function getPlace(zip){
    getTax(zip);

    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function(){
        if(xhr.readyState == 4 && xhr.status ==200){
            var result = xhr.responseText;
            var place = result.split(',');
            if(document.getElementById("city").value === ""){
                document.getElementById("city").value = place[0];
            }

            document.getElementById("state").value = place[1];

        }
    };
    xhr.open("GET", "./../getCityState?zip="+zip, true);
    xhr.send();

}

function getTax(zip){
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function(){
        if(xhr.readyState == 4 && xhr.status ==200){
            var result = xhr.responseText;
            var place = result.split(',');


            var totprice2 = parseFloat(document.getElementById("carttotal2").innerText);


            if(place.length ==2){
                document.getElementById("tax_rate").innerText = place[0];

                document.getElementById("tax_region").innerText = place[1];

                document.getElementById("taxtotal").innerText = (totprice2 + totprice2*parseFloat(place[0])).toFixed(2);
                document.getElementById("taxcalculation").innerHTML = totprice2 + " + "  +totprice2 +" x " + (place[0]);

                document.getElementById("hiddentotal").value= (totprice2 + totprice2*parseFloat(place[0])).toFixed(2);
            }else{
                document.getElementById("tax_rate").innerText = 0.0;

                document.getElementById("tax_region").innerText = "Not Found";

                document.getElementById("taxtotal").innerText = totprice2 + totprice2*(0);
                document.getElementById("taxcalculation").innerHTML = totprice2 + " + "  +totprice2 +" x " + (0);
                document.getElementById("hiddentotal").value= (totprice2).toFixed(2);
            }


        }
    };
    xhr.open("GET", "./../getTax?zip="+zip, true);
    xhr.send();

}








// When the user scrolls the page, execute myFunction
window.onscroll = function() {stickyScroll()};

// Get the title
var header = document.getElementById("myHeader");

// Get the offset position of the navbar
var sticky = header.offsetTop;

// Add the sticky class to the header when you reach its scroll position. Remove "sticky" when you leave the scroll position
function stickyScroll() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}
