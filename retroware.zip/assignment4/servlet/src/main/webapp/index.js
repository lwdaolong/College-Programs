

/*document.querySelector("form").addEventListener("submit", function(event) {
    const quantityEl = document.querySelector("#quantity");
    const quantity = quantityEl.value;
    if (quantity < 2 || quantity > 10) {
      alert("Quantity must be between 2 and 10");
      event.preventDefault(); 
    } else {
      const formData = {
        name: document.querySelector("#name").value,
        email: document.querySelector("#email").value,
        product: document.querySelector("#product").value,
        quantity: quantity,
        city: document.querySelector("#city").value
      };
      sessionStorage.setItem("formData", JSON.stringify(formData));
      
    }
  });
  
const storedFormData = sessionStorage.getItem("formData");
if (storedFormData){
  const formDataContainer = document.querySelector(".formDataContainer");
  formDataContainer.style.display = "block";
  const formData = JSON.parse(storedFormData);
  formDataContainer.innerHTML = `
    <div class="card">
    <div class="card-header">Saved Form Data</div>
    <div class="card-body">
      <p><strong>Name:</strong> ${formData.name}</p>
      <p><strong>Email:</strong> ${formData.email}</p>
      <p><strong>Product:</strong> ${formData.product}</span></p>
      <p><strong>Quantity:</strong> ${formData.quantity}</p>
      <p><strong>City:</strong> ${formData.city}</p>
    </div>
  </div>
  `;
}
*/

// When the user scrolls the page, execute myFunction
window.onscroll = function() {stickyScroll()};

// Get the title
var header = document.getElementById("myHeader");

// Get the offset position of the navbar
var sticky = header.offsetTop;

// Add the sticky class to the header when you reach its scroll position. Remove "sticky" when you leave the scroll position
function stickyScroll() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}
  
