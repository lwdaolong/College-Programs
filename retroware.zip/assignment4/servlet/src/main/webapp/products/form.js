document.querySelector("form").addEventListener("submit", function(event) {

    //find price with querySelector for price id of product based on product page

    const quantityEl = document.querySelector("#quantity");
    const quantity = quantityEl.value;
    if (quantity < 1 || quantity > 10) {
      alert("Quantity must be between 2 and 10");
      event.preventDefault(); 
    } else {
      const formData = {
        fname: document.querySelector("#fname").value,
        lname: document.querySelector("#lname").value,
        email: document.querySelector("#email").value,
        phone: document.querySelector("#phone").value,
        product: document.querySelector("#product").value,
        quantity: quantity,
        address: document.querySelector("#address").value,
        country: document.querySelector("#country").value,
        zipcode: document.querySelector("#zipcode").value,
        city: document.querySelector("#city").value,
        state: document.querySelector("#state").value,
        shipping: document.querySelector("#shipping").value,
        cc: document.querySelector("#cc").value,
        exp: document.querySelector("#exp").value,
        cvc: document.querySelector("#cvc").value,
        cost: document.querySelector('#total_price').innerHTML
      };
      sessionStorage.setItem("formData", JSON.stringify(formData));

      let prettyEmail = prettyFormData(formData);
      window.open('mailto:'+formData.email+'?subject='+formData.product+' Order&body='+prettyEmail);
      //TODO make a method that turns the JSON object formData into correct email body string
    }


  });

/*
const storedFormData = sessionStorage.getItem("formData");
if (storedFormData){
  const formDataContainer = document.querySelector(".formDataContainer");
  formDataContainer.style.display = "block";
  const formData = JSON.parse(storedFormData);
  formDataContainer.innerHTML = `
    <div class="card">
    <div class="card-header">Saved Form Data</div>
    <div class="card-body">
      <p><strong>First Name:</strong> ${formData.fname}</p>
      <p><strong>Email:</strong> ${formData.email}</p>
      <p><strong>Product:</strong> ${formData.product}</span></p>
      <p><strong>Quantity:</strong> ${formData.quantity}</p>
      <p><strong>City:</strong> ${formData.city}</p>
    </div>
  </div>
  `;
}
*/


// When the user scrolls the page, execute myFunction
window.onscroll = function() {stickyScroll()};

// Get the title
var header = document.getElementById("myHeader");

// Get the offset position of the navbar
var sticky = header.offsetTop;

// Add the sticky class to the header when you reach its scroll position. Remove "sticky" when you leave the scroll position
function stickyScroll() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}

function prettyFormData(formData){
      var prettystring = `
Hello ${formData.fname} ${formData.lname},

Thank you for shopping with us. This email should detail the contents of your order:

Product: ${formData.product}
Quantity: ${formData.quantity}
Cost: ${formData.cost}

Phone Number: ${formData.phone}
Email: ${formData.email}

Shipping Address:
${formData.address}
${formData.city}, ${formData.state} ${formData.zipcode}

Shipping Method: ${formData.shipping}

Payment Information:
    CC: ${formData.cc}
    Expiration: ${formData.exp}
    CVC: ${formData.cvc}

We hope to see you again soon.
RetroWare.com
      `;
      return encodeURIComponent(prettystring);
}

function modifyPrice(){
    const quantityEl = document.querySelector("#quantity");
    const quantity = quantityEl.value;
    const originalpriceE1 = document.querySelector("#original-price");
    const originalprice = originalpriceE1.innerHTML;
    //console.log(originalprice);

    let newprice = quantity*originalprice.substr(1);
    //console.log(newprice);

    let totprice = document.querySelector("#total_price").innerHTML = '$'+newprice;


    //let newprice = quantity * ;


}
  
